"""Wormhole clustering on the 36 wormhole runs, in the same procedure as the blackhole clustering (clu_lib.py).
Population 1: the non-attacker boards (children, 'not tunnelled'); the label is attack (2) vs normal (0). The wormhole acts on the probes of
              the entry end only, so nothing is done to these boards and the expected agreement with the label is none.
Population 2: the exit end A.  Population 3: the entry end B.  Feature sets without tunnel features (cross-layer only; B also with
              LatencyHopRatio) and, as a diagnostic that the leakage audit excludes from model inputs, with TunnelIntensity.
Writes out/csv/wh_cl_*.csv, pkl/wh_cl_*.pkl.   Run:  OMP_NUM_THREADS=1 python3 an_wh_cluster.py"""
import os, sys, pickle, warnings
import numpy as np, pandas as pd
from cfg import *
from clu_lib import *
import leakage
warnings.filterwarnings("ignore")
O = CSV
if os.environ.get("SMOKE"):
    SEEDS, KS, N_SAMPLE = [42, 7], [2, 3], 500
    O = O + "/smoke"; os.makedirs(O, exist_ok=True)

raw = pd.read_pickle(PKL + "/pooled_raw.pkl")
wh = raw[(raw.kind == "wormhole") & raw.Label.notna()].copy()
wh["y"] = (wh.Label > 0).astype(int)
XL = ["RSSI_mean", "RSSI_var", "RSSI_Hop_Diff"]
child = wh[wh.node_role == "child"].dropna(subset=FULL).copy()
A = wh[wh.node_role == "wormhole_a"].dropna(subset=XL + ["TunnelIntensity"]).copy()
B = wh[wh.node_role == "wormhole_b"].dropna(subset=XL + ["TunnelIntensity", "LatencyHopRatio"]).copy()
print(f"windows: children {len(child):,} (of {int((wh.node_role == 'child').sum()):,}); A {len(A):,}; B {len(B):,}")
low = {f: child[f].round(6).value_counts(normalize=True).iloc[0] for f in FULL}
print("share of the most common value in the wormhole children:", {k: round(v, 4) for k, v in low.items()})
pd.DataFrame([dict(feature=k, share_most_common=v) for k, v in low.items()]).to_csv(O + "/wh_cl_lowvariance_check.csv", index=False)

PO = [("wormhole non-attacker boards", child, SETS),
      ("exit end A", A, {"cross-layer (3)": XL, "cross-layer + TunnelIntensity (4)": XL + ["TunnelIntensity"]}),
      ("entry end B", B, {"cross-layer (3)": XL, "cross-layer + LatencyHopRatio (4)": XL + ["LatencyHopRatio"],
                           "cross-layer + TunnelIntensity (4)": XL + ["TunnelIntensity"]})]
res_l, db_l, store = [], [], {}
for pop, base, sets in PO:
    r, d, s = sweep(base, sets, "y", pop, oracle_col=None, seeds=SEEDS, ks=KS, n_sample=N_SAMPLE)
    res_l.append(r); db_l.append(d); store.update(s)
res = pd.concat(res_l); res.to_csv(O + "/wh_cl_all_runs.csv", index=False)
pd.concat(db_l).to_csv(O + "/wh_cl_dbscan_parameter_search.csv", index=False)
pickle.dump(store, open(PKL + "/wh_cl_assign_store.pkl", "wb"))
pickle.dump(dict(child=child, A=A, B=B), open(PKL + "/wh_cl_work.pkl", "wb"))
agg, dbagg, summ = summarise(res)
pd.concat([agg, dbagg]).to_csv(O + "/wh_cl_mean_over_seeds.csv", index=False)
summ.to_csv(O + "/wh_cl_summary.csv", index=False)
pickle.dump(dict(res=res, agg=agg, dbagg=dbagg, summ=summ, PO=[(p, s) for p, _, s in PO]), open(PKL + "/wh_cl_summary.pkl", "wb"))
pd.set_option("display.width", 250)
print(summ[["population", "feature_set", "algorithm", "selection", "k", "silhouette", "DB", "purity", "majority", "ARI", "noise"]].round(3).to_string())

# cluster profiles (K-Means k = 2, seed 42)
prof = []
setmap = {p: s for p, _, s in PO}
basemap = {p: b for p, b, _ in PO}
for (pop, sname, tag), (idx, lab, _, _) in store.items():
    if not tag.startswith("KMeans"): continue
    d = basemap[pop].loc[idx].copy(); d["cluster"] = lab
    for c, g in d.groupby("cluster"):
        r = dict(population=pop, feature_set=sname, model=tag, cluster=c, n=len(g), attack_share=g.y.mean(),
                 baseline_share=(g.phase == "baseline").mean(), attack_phase_share=(g.phase == "attack").mean(), cooldown_share=(g.phase == "cooldown").mean())
        for f in setmap[pop][sname]: r["mean_" + f] = g[f].mean()
        prof.append(r)
pd.DataFrame(prof).to_csv(O + "/wh_cl_profiles_kmeans.csv", index=False)
print("done")
