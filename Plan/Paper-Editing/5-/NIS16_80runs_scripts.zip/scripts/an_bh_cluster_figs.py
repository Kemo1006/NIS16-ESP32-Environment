"""Figures of the blackhole clustering (Chapter 6, Section 6.4), redrawn from the stored results of an_bh_cluster.py so that the wording
matches the chapter (victim / bystander), the ARI panels share one vertical scale, and no legend covers a bar.
Reads out/csv/bh_clustering_*.csv, pkl/bh_use.pkl, pkl/bh_assign_store.pkl.  Writes out/fig/bh_fig7..fig12 (same names as before)."""
import pickle, warnings
import numpy as np, pandas as pd
from cfg import *
from clu_lib import FULL, REDUCED, NOPDR, SETS, SEEDS, N_SAMPLE
warnings.filterwarnings("ignore")
plt = mpl()
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from matplotlib.patches import Patch
O, OF = CSV, FIG
NOTE = f"Blackhole · 36 runs · THESIS3 @ {COMMIT} · 24 Oct 2026"
res = pd.read_csv(O + "/bh_clustering_all_runs.csv")
agg = pd.read_csv(O + "/bh_clustering_mean_over_seeds.csv")
store = pickle.load(open(PKL + "/bh_assign_store.pkl", "rb"))
u = pd.read_pickle(PKL + "/bh_use.pkl")
ch = u[(u.node_role == "child") & u.Label.notna()].copy(); ch["y"] = (ch.Label > 0).astype(int)
work = ch.dropna(subset=FULL).copy()
algos = ["KMeans", "Ward", "GMM", "Spectral"]
cols = {"KMeans": "#2b6cb0", "Ward": "#2f855a", "GMM": "#805ad5", "Spectral": "#dd6b20"}
pops = {"all child nodes": "all non-attacker nodes", "victims only": "victims only"}
YL = {"all child nodes": (-0.1, 0.65), "victims only": (-0.1, 1.15)}


def sweep(metric, ylabel, fname, title, ylim=None):
    fig, axes = plt.subplots(3, 2, figsize=(10.4, 8.8), sharex=True)
    for i, sname in enumerate(SETS):
        for j, pop in enumerate(pops):
            ax = axes[i, j]
            for a in algos:
                g = agg[(agg.population == pop) & (agg.feature_set == sname) & (agg.algorithm == a)].sort_values("k")
                sd = res[(res.population == pop) & (res.feature_set == sname) & (res.algorithm == a)].groupby("k")[metric].std().reindex(g.k).values
                ax.errorbar(g.k, g[metric], yerr=sd, label=a, color=cols[a], marker="o", ms=3, lw=1.3, capsize=2)
            d = agg[(agg.population == pop) & (agg.feature_set == sname) & (agg.algorithm == "DBSCAN")]
            if len(d) and np.isfinite(d[metric].iloc[0]):
                ax.axhline(d[metric].iloc[0], color="#444", ls=":", lw=1, label=f"DBSCAN (k per seed {d.k_per_seed.iloc[0]})")
            if metric == "ARI_all":
                ax.axhline(0, color=C_GREY, lw=.7); ax.set_ylim(*YL[pop])
            ax.set_title(f"{sname.replace('_', ' ')} ({len(SETS[sname])} features) · {pops[pop]}", fontsize=8.5)
            ax.set_ylabel(ylabel)
            if i == 2: ax.set_xlabel("k (number of clusters)")
    hh, ll = axes[0, 0].get_legend_handles_labels()
    fig.legend(hh, ll, loc="lower center", ncol=5, frameon=False, fontsize=8, bbox_to_anchor=(.5, -.02))
    fig.suptitle(title, fontweight="bold", y=1.0)
    fig.text(0.01, -0.035, NOTE + f" · mean ± sd over seeds {SEEDS}, n = {N_SAMPLE:,} windows per seed", fontsize=7, color=C_GREY)
    fig.tight_layout(rect=(0, .03, 1, 1)); fig.savefig(OF + "/bh_" + fname, bbox_inches="tight"); plt.close(fig)


sweep("ARI_all", "ARI against the label", "fig7_cluster_ARI_vs_k.png", "Blackhole runs: agreement of the clusters with the label (ARI) against k")
sweep("silhouette", "silhouette", "fig8a_cluster_silhouette_vs_k.png", "Blackhole runs: silhouette score against k (higher = better separated)")
sweep("DB", "Davies–Bouldin", "fig8b_cluster_DB_vs_k.png", "Blackhole runs: Davies–Bouldin index against k (lower = better separated)")

# DBSCAN k-distance
fig, axes = plt.subplots(1, 3, figsize=(12, 3.4))
for ax, sname in zip(axes, SETS):
    idx, lab, kd, eps = store[("all child nodes", sname, "DBSCAN")]
    ax.plot(kd, color="#2b6cb0"); ax.axhline(eps, color=C_ATT, ls="--", lw=1); ax.set_ylim(0, 3)
    ncl = len(set(lab)) - (1 if -1 in lab else 0)
    ax.set_title(f"{sname.replace('_', ' ')}: eps = {eps:.2f}, {ncl} cluster(s), {np.mean(lab == -1):.0%} noise", fontsize=8.5)
    ax.set_xlabel("windows sorted by k-distance"); ax.set_ylabel("k-distance (standardised units)")
fig.suptitle("Blackhole runs: DBSCAN k-distance graphs, all non-attacker nodes, seed 42", fontweight="bold", y=1.02)
fig.text(0.01, -0.04, NOTE, fontsize=7, color=C_GREY)
fig.tight_layout(); fig.savefig(OF + "/bh_fig9_dbscan_kdistance.png", bbox_inches="tight"); plt.close(fig)
kdmax = {s: float(np.max(store[("all child nodes", s, "DBSCAN")][2])) for s in SETS}
pd.Series(kdmax).to_csv(O + "/bh_kdistance_max.csv", header=["max_k_distance"])

# PCA / t-SNE (seed 42 sample, the same 6,000 windows)
GRP = ["victim · attack", "bystander · attack", "victim · normal", "bystander · normal"]
PAL = {"victim · attack": C_ATT, "bystander · attack": "#63b3ed", "victim · normal": "#f6ad55", "bystander · normal": "#2b6cb0"}


def grp(d):
    return np.where(d.exposure == "downstream", np.where(d.y == 1, "victim · attack", "victim · normal"),
                    np.where(d.y == 1, "bystander · attack", "bystander · normal"))


samp = work.sample(N_SAMPLE, random_state=42)
g_ = grp(samp)
rows = []
for fname, feats, title in (("fig10_pca_tsne_full.png", FULL, f"Blackhole runs: the {len(FULL)} features of the FULL set, {N_SAMPLE:,} windows of non-attacker nodes"),
                            ("fig11_pca_tsne_without_pdr.png", NOPDR, f"Blackhole runs: the same windows without PDR ({', '.join(NOPDR)})")):
    X = StandardScaler().fit_transform(samp[feats].values)
    pc = PCA(2, random_state=42).fit(X); Z = pc.transform(X)
    ts = TSNE(2, perplexity=40, random_state=42, init="pca").fit_transform(X)
    rows.append(dict(figure=fname, PC1=pc.explained_variance_ratio_[0], PC2=pc.explained_variance_ratio_[1]))
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.6))
    for ax, E, nm in ((axes[0], Z, f"PCA (PC1 {pc.explained_variance_ratio_[0]:.0%}, PC2 {pc.explained_variance_ratio_[1]:.0%})"), (axes[1], ts, "t-SNE (perplexity 40)")):
        for k_ in ["bystander · normal", "victim · normal", "bystander · attack", "victim · attack"]:
            m = g_ == k_
            ax.scatter(E[m, 0], E[m, 1], s=4, alpha=.45, color=PAL[k_], label=f"{k_} ({m.sum():,})", lw=0)
        ax.set_title(nm)
    hh, ll = axes[0].get_legend_handles_labels(); order = [3, 2, 1, 0]
    axes[0].legend([hh[i] for i in order], [ll[i] for i in order], markerscale=3, frameon=False, fontsize=7.5)
    fig.suptitle(title, fontweight="bold")
    fig.text(0.01, -0.02, NOTE, fontsize=7, color=C_GREY)
    fig.tight_layout(); fig.savefig(OF + "/bh_" + fname, bbox_inches="tight"); plt.close(fig)
pd.DataFrame(rows).to_csv(O + "/bh_pca_variance.csv", index=False)

# composition of the K-Means clusters at k = 3 (seed 42)
fig, axes = plt.subplots(1, 3, figsize=(12, 3.9), sharey=True)
for ax, sname in zip(axes, SETS):
    idx, lab, _, _ = store[("all child nodes", sname, "KMeans3")]
    d = work.loc[idx].copy(); d["cluster"] = lab; d["grp"] = grp(d)
    ct = pd.crosstab(d.cluster, d.grp, normalize="index"); n = d.cluster.value_counts().sort_index()
    bottom = np.zeros(len(ct))
    for g in GRP:
        if g in ct:
            ax.bar([f"Cluster {c}\n(n = {n[c]:,})" for c in ct.index], ct[g], bottom=bottom, color=PAL[g]); bottom += ct[g].values
    ax.set_title(f"{sname.replace('_', ' ')}, K-Means k = 3", fontsize=9)
axes[0].set_ylabel("share of the windows of the cluster")
fig.legend(handles=[Patch(color=PAL[g], label=g) for g in GRP], loc="lower center", ncol=4, frameon=False, fontsize=8, bbox_to_anchor=(.5, -.07))
fig.suptitle("Blackhole runs: what each K-Means cluster contains (all non-attacker nodes, seed 42)", fontweight="bold", y=1.02)
fig.text(0.01, -0.11, NOTE, fontsize=7, color=C_GREY)
fig.tight_layout(); fig.savefig(OF + "/bh_fig12_cluster_composition.png", bbox_inches="tight"); plt.close(fig)
print("done")
