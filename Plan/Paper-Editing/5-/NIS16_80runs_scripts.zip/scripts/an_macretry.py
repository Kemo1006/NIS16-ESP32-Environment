"""MacRetryRate (real 802.11 retry rate from the sniffer, a supplementary column) in the blackhole runs: which runs have it, and does it change in the attack?
Reads pkl/pooled_raw.pkl.  Writes out/csv/bh_macretry_*.csv"""
import numpy as np, pandas as pd
from cfg import *
raw = pd.read_pickle(PKL + "/pooled_raw.pkl")
print([c for c in raw.columns if 'Mac' in c or 'mac' in c])
k = raw[raw.phase.notna() & (raw.kind == "blackhole") & (raw.node_role == "child")].copy()
k["has"] = k.MacRetryRate.notna()
print("windows with a value:", int(k.has.sum()), "of", len(k))
byrun = k.groupby("cell").agg(n=("has", "size"), withval=("has", "sum"), boards=("node_id", "nunique"))
byrun["share"] = byrun.withval / byrun.n
print((byrun.withval > 0).sum(), "runs with any MacRetryRate;", (byrun.share > 0.5).sum(), "with more than half")
print(byrun.sort_values("share").to_string())
byrun.to_csv(CSV + "/bh_macretry_runs.csv")
if "MacFramesHeard" in k:
    print(k.groupby(["exposure", "phase"]).agg(windows=("has", "sum"), mean_rate=("MacRetryRate", "mean"), frames=("MacFramesHeard", "sum")))

# ---- frame-weighted rate by exposure and phase, in the runs that have a capture
m = k[k.has].copy()
m["retries"] = m.MacRetryRate * m.MacFramesHeard
rows = []
for expo in ("downstream", "upstream"):
    for ph in ("baseline", "attack", "cooldown"):
        g = m[(m.exposure == expo) & (m.phase == ph)]
        rows.append(dict(exposure=expo, phase=ph, runs=g.cell.nunique(), boards=g.groupby("cell").node_id.nunique().sum(), windows=len(g), frames=g.MacFramesHeard.sum(),
                         weighted_rate=g.retries.sum() / g.MacFramesHeard.sum(), mean_of_windows=g.MacRetryRate.mean()))
t = pd.DataFrame(rows); t.to_csv(CSV + "/bh_macretry_by_phase.csv", index=False); print(t.round(4).to_string())
# per run (only runs with more than half of their windows measured): attack minus baseline, frame-weighted
good = byrun[byrun.withval > 0].index
pr = []
for cell in good:
    for expo in ("downstream", "upstream"):
        g = m[(m.cell == cell) & (m.exposure == expo)]
        if g.empty: continue
        r = {}
        for ph in ("baseline", "attack", "cooldown"):
            h = g[g.phase == ph]
            r[ph] = h.retries.sum() / h.MacFramesHeard.sum() if h.MacFramesHeard.sum() > 0 else np.nan
            r[ph + "_frames"] = h.MacFramesHeard.sum()
        pr.append(dict(cell=cell, exposure=expo, **r))
pr = pd.DataFrame(pr); pr["attack_minus_baseline"] = pr.attack - pr.baseline
pr.to_csv(CSV + "/bh_macretry_per_run.csv", index=False); print(pr.round(3).to_string())
print(pr.groupby("exposure").attack_minus_baseline.describe())
