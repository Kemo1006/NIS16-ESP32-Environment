"""Figures of the wormhole clustering, from the pickles written by an_wh_cluster.py.
wh_cl_fig1: ARI against k for the three populations.  wh_cl_fig2: PCA and t-SNE of the non-attacker boards and of the two tunnel ends."""
import pickle, warnings
import numpy as np, pandas as pd
from cfg import *
from clu_lib import *
warnings.filterwarnings("ignore")
plt = mpl()
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
O, OF = CSV, FIG
NOTE = f"Wormhole · 36 runs · THESIS3 @ {COMMIT} · 24 Oct 2026"
S = pickle.load(open(PKL + "/wh_cl_summary.pkl", "rb"))
W = pickle.load(open(PKL + "/wh_cl_work.pkl", "rb"))
res, agg, dbagg, PO = S["res"], S["agg"], S["dbagg"], dict(S["PO"])
algos = ["KMeans", "Ward", "GMM", "Spectral"]
cols = {"KMeans": "#2b6cb0", "Ward": "#2f855a", "GMM": "#805ad5", "Spectral": "#dd6b20"}
pops = list(PO)
ncol = max(len(v) for v in PO.values())
fig, axes = plt.subplots(len(pops), ncol, figsize=(4.4 * ncol, 2.9 * len(pops)), sharex=True, squeeze=False)
for i, pop in enumerate(pops):
    for j in range(ncol):
        ax = axes[i, j]
        if j >= len(PO[pop]): ax.axis("off"); continue
        sname = list(PO[pop])[j]
        for a in algos:
            g = agg[(agg.population == pop) & (agg.feature_set == sname) & (agg.algorithm == a)].sort_values("k")
            sd = res[(res.population == pop) & (res.feature_set == sname) & (res.algorithm == a)].groupby("k").ARI.std().reindex(g.k).values
            ax.errorbar(g.k, g.ARI, yerr=sd, label=a, color=cols[a], marker="o", ms=3, lw=1.3, capsize=2)
        d = dbagg[(dbagg.population == pop) & (dbagg.feature_set == sname)]
        if len(d): ax.axhline(d.ARI.iloc[0], color="#444", ls=":", lw=1, label=f"DBSCAN (k per seed {d.k_per_seed.iloc[0]})")
        ax.axhline(0, color=C_GREY, lw=.7)
        ax.set_ylim(-0.1, 1.05 if "Tunnel" in sname else 0.35)
        popn = pop.replace("wormhole non-attacker boards", "non-attacker boards")
        snm = sname.replace("REDUCED_no_PDR", "REDUCED without PDR (3)").replace("FULL", "FULL (8)").replace("REDUCED", "REDUCED (4)") if sname in ("FULL", "REDUCED", "REDUCED_no_PDR") else sname
        snm = snm.replace("REDUCED (4) without PDR (3)", "REDUCED without PDR (3)")
        ax.set_title(f"{popn} · {snm}", fontsize=8)
        ax.set_ylabel("ARI")
        if i == len(pops) - 1: ax.set_xlabel("k (number of clusters)")
axes[0, 0].legend(frameon=False, fontsize=6.5, ncol=2, loc="upper left")
fig.suptitle("Wormhole runs: agreement of the clusters with the attack label (ARI) against k", fontweight="bold", y=1.0)
fig.text(0.01, -0.01, NOTE + f" · mean ± sd over seeds {SEEDS}, n = {N_SAMPLE:,} windows per seed · the vertical scale is wider in the two panels that include TunnelIntensity", fontsize=7, color=C_GREY)
fig.tight_layout(); fig.savefig(OF + "/wh_cl_fig1_ARI_vs_k.png", bbox_inches="tight"); plt.close(fig)

# PCA / t-SNE
XL = ["RSSI_mean", "RSSI_var", "RSSI_Hop_Diff"]
panels = [("non-attacker boards, FULL (8 features)", W["child"], FULL), ("entry end B, cross-layer (3)", W["B"], XL),
          ("entry end B, cross-layer + TunnelIntensity (4)", W["B"], XL + ["TunnelIntensity"])]
fig, axes = plt.subplots(2, 3, figsize=(13, 7.6))
col = {"baseline": C_BASE, "attack": C_WH, "cooldown": "#9ae6b4"}
for j, (nm, d, feats) in enumerate(panels):
    s = d.sample(min(N_SAMPLE, len(d)), random_state=42)
    X = StandardScaler().fit_transform(s[feats].values)
    pc = PCA(2, random_state=42).fit(X); Z = pc.transform(X)
    ts = TSNE(2, perplexity=40, random_state=42, init="pca").fit_transform(X)
    for r, (E, en) in enumerate(((Z, f"PCA (PC1 {pc.explained_variance_ratio_[0]:.0%}, PC2 {pc.explained_variance_ratio_[1]:.0%})"), (ts, "t-SNE (perplexity 40)"))):
        ax = axes[r, j]
        for ph in ("baseline", "cooldown", "attack"):
            m = (s.phase == ph).values
            ax.scatter(E[m, 0], E[m, 1], s=4, alpha=.5, color=col[ph], label=f"{ph} ({m.sum():,})", lw=0)
        ax.set_title(f"{nm}\n{en}", fontsize=8)
    axes[0, j].legend(markerscale=3, frameon=False, fontsize=7)
fig.suptitle("Wormhole runs: windows projected to two dimensions, coloured by phase", fontweight="bold")
fig.text(0.01, -0.01, NOTE, fontsize=7, color=C_GREY)
fig.tight_layout(); fig.savefig(OF + "/wh_cl_fig2_pca_tsne.png", bbox_inches="tight"); plt.close(fig)
print("done")
