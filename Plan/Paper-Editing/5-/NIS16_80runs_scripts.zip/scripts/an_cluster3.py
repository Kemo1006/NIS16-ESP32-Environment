"""Pooled three-label clustering of the non-attacker boards of all 80 runs (normal 0, blackhole 1, wormhole 2).
Population A: all 80 runs (36 blackhole + 36 wormhole + 8 benign).  Population B (sensitivity): the 72 attack runs without the benign runs.
Same procedure as the blackhole clustering (clu_lib.py). Writes out/csv/cl3_*.csv, out/fig/cl3_fig*.png, pkl/cl3_*.pkl
Run:  OMP_NUM_THREADS=1 python3 an_cluster3.py        (do not use -I)"""
import os, sys, pickle, warnings
import numpy as np, pandas as pd
from cfg import *
from clu_lib import *
import leakage
warnings.filterwarnings("ignore")
plt = mpl()
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
O, OF = CSV, FIG
NOTE = f"Pooled non-attacker boards · 80 runs · THESIS3 @ {COMMIT} · 24 Oct 2026"
if os.environ.get("SMOKE"):
    import clu_lib; SEEDS, KS, N_SAMPLE = [42, 7], [2, 3], 500
    O = O + "/smoke"; OF = OF + "/smoke"; os.makedirs(O, exist_ok=True); os.makedirs(OF, exist_ok=True)

raw = pd.read_pickle(PKL + "/pooled_raw.pkl")
ch = raw[(raw.node_role == "child") & raw.Label.notna()].copy()
ch["Label"] = ch.Label.astype(int)
def grp(r_kind, lab, expo):
    if r_kind == "benign": return "normal · benign run"
    if r_kind == "blackhole":
        if lab == 0: return "normal · blackhole run"
        return "blackhole attack · victim" if expo == "downstream" else "blackhole attack · bystander"
    return "normal · wormhole run" if lab == 0 else "wormhole attack · other board"
ch["grp"] = [grp(a, b, c) for a, b, c in zip(ch.kind, ch.Label, ch.exposure)]
ch["oracle"] = (ch.grp == "blackhole attack · victim")
GRPS = ["normal · benign run", "normal · blackhole run", "normal · wormhole run",
        "blackhole attack · victim", "blackhole attack · bystander", "wormhole attack · other board"]
GCOL = {"normal · benign run": "#2f855a", "normal · blackhole run": "#2b6cb0", "normal · wormhole run": "#805ad5",
        "blackhole attack · victim": "#c53030", "blackhole attack · bystander": "#f6ad55", "wormhole attack · other board": "#d53f8c"}

# --- check that the feature-set rules, applied to the pooled windows, give the sets used for the blackhole (Table 6.9)
aud = leakage.single_feature_decidability(ch.assign(window_label=ch.Label), candidates=leakage.TABLE_4_11_FEATURES)
allowed, excluded = leakage.split_columns(ch)
cov = ch[leakage.TABLE_4_11_FEATURES].notna().mean()
print("allowed by leakage.py:", allowed)
print("excluded by leakage.py:", list(excluded))
print(aud[["feature", "threshold_accuracy", "nan_accuracy", "coverage"]].round(3).to_string())
work = ch.dropna(subset=FULL).copy()
print(f"complete rows {len(work):,} of {len(ch):,} non-attacker windows ({len(ch) - len(work):,} dropped for NaN in FULL)")
lowvar = [f for f in FULL if work[f].round(6).value_counts(normalize=True).iloc[0] > .90]
print("low-variance rule (>90 % identical) on the pooled windows would drop:", lowvar)
bh_only = work[work.kind == "blackhole"]
lowvar_bh = [f for f in FULL if bh_only[f].round(6).value_counts(normalize=True).iloc[0] > .90]
print("   on the blackhole windows alone it drops:", lowvar_bh)
assert "PDR" not in lowvar_bh and set(lowvar_bh) == {"ParentSwitchRate", "HopChangeCount", "HopStabilityDuration", "RSSI_stability"}
# the sets of Table 6.9 (derived on the blackhole windows) are kept for every pooled analysis, so that the results stay comparable;
# on the pooled windows PDR sits at 1.000 in most windows because an attack is rare, which the 90 % rule would read as 'no information'
corr = work[REDUCED].corr().abs()
mx = corr.where(~np.eye(len(REDUCED), dtype=bool)).max().max()
print("largest |r| among the four REDUCED features (pooled):", round(mx, 3))
filt = pd.DataFrame([dict(feature=f, share_most_common_pooled=work[f].round(6).value_counts(normalize=True).iloc[0],
                          share_most_common_blackhole=bh_only[f].round(6).value_counts(normalize=True).iloc[0],
                          share_most_common_wormhole=work[work.kind == "wormhole"][f].round(6).value_counts(normalize=True).iloc[0],
                          share_most_common_benign=work[work.kind == "benign"][f].round(6).value_counts(normalize=True).iloc[0]) for f in FULL])
filt.to_csv(O + "/cl3_lowvariance_check.csv", index=False); print(filt.round(4).to_string())
pd.DataFrame([dict(item="complete rows", value=len(work)), dict(item="all non-attacker windows", value=len(ch)),
              dict(item="largest |r| among kept features", value=mx)]).to_csv(O + "/cl3_pool_counts.csv", index=False)
print(work.groupby(["kind", "grp"]).size())
work.groupby(["kind", "grp"]).size().rename("windows").reset_index().to_csv(O + "/cl3_pool_by_group.csv", index=False)

pops = {"80 runs (with benign)": work, "72 attack runs (no benign)": work[work.kind != "benign"]}
res_l, db_l, store = [], [], {}
for pop, base in pops.items():
    r, d, s = sweep(base, SETS, "Label", pop, oracle_col="oracle", seeds=SEEDS, ks=KS, n_sample=N_SAMPLE)
    res_l.append(r); db_l.append(d); store.update(s)
res = pd.concat(res_l); res.to_csv(O + "/cl3_clustering_all_runs.csv", index=False)
pd.concat(db_l).to_csv(O + "/cl3_dbscan_parameter_search.csv", index=False)
pickle.dump(store, open(PKL + "/cl3_assign_store.pkl", "wb"))
work.to_pickle(PKL + "/cl3_work.pkl")
agg, dbagg, summ = summarise(res)
pd.concat([agg, dbagg]).to_csv(O + "/cl3_clustering_mean_over_seeds.csv", index=False)
summ.to_csv(O + "/cl3_clustering_summary.csv", index=False)
pd.set_option("display.width", 250)
print(summ[["population", "feature_set", "algorithm", "selection", "k", "silhouette", "DB", "purity", "majority", "ARI", "ARI_binary", "ARI_oracle", "noise"]].round(3).to_string())

# --- cluster profiles of K-Means seed 42 (k = 2, 3, 4)
prof = []
for (pop, sname, tag), (idx, lab, _, _) in store.items():
    if not tag.startswith("KMeans"): continue
    d = work.loc[idx].copy(); d["cluster"] = lab
    for c, g in d.groupby("cluster"):
        r = dict(population=pop, feature_set=sname, model=tag, cluster=c, n=len(g))
        for G in GRPS: r["share_" + G] = (g.grp == G).mean()
        for L in (0, 1, 2): r[f"label{L}_share"] = (g.Label == L).mean()
        for f in FULL:
            if f in SETS[sname]: r["mean_" + f] = g[f].mean()
        prof.append(r)
prof = pd.DataFrame(prof); prof.to_csv(O + "/cl3_cluster_profiles_kmeans.csv", index=False)

pickle.dump(dict(res=res, agg=agg, dbagg=dbagg, summ=summ, pl=list(pops)), open(PKL + "/cl3_summary.pkl", "wb"))
print("sweep done")
