"""Run-level check of the clustering result (Section 6.4.4 of the draft): one K-Means model is fitted on a sample of 6,000 windows
(seed 42), applied to EVERY window of the population, and the agreement with the label is computed over all windows. The runs are
then resampled with replacement (300 times) to give a 95 % interval that reflects run-to-run variation, and inside each run the model
is compared with the best possible partition of that run (the oracle: the windows in which the attack is felt).
Writes out/csv/boot_summary.csv and boot_per_run.csv.  Run: OMP_NUM_THREADS=1 python3 an_boot.py"""
import warnings
import numpy as np, pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score
from cfg import *
from clu_lib import FULL, REDUCED, NOPDR
warnings.filterwarnings("ignore")
B_RES, SEED, N = 300, 42, 6000
raw = pd.read_pickle(PKL + "/pooled_raw.pkl")
ch = raw[(raw.node_role == "child") & raw.Label.notna()].dropna(subset=FULL).copy()
ch["Label"] = ch.Label.astype(int)
ch["oracle"] = ((ch.kind == "blackhole") & (ch.exposure == "downstream") & (ch.Label == 1)).astype(int)


def ari_from_table(T):
    """adjusted Rand index from a contingency table (rows = label, columns = cluster)"""
    T = np.asarray(T, dtype=float)
    n = T.sum()
    c2 = lambda x: x * (x - 1) / 2.0
    sij = c2(T).sum(); a = c2(T.sum(1)).sum(); b = c2(T.sum(0)).sum()
    exp = a * b / c2(n); mx = (a + b) / 2
    return (sij - exp) / (mx - exp) if mx != exp else np.nan


def table(y, c, ny, nc):
    T = np.zeros((ny, nc))
    np.add.at(T, (y, c), 1)
    return T


def analyse(name, df, feats, k, label_col, oracle=True, rng_seed=1):
    df = df.copy()
    X = df[feats].values
    samp = df.sample(min(N, len(df)), random_state=SEED)
    sc = StandardScaler().fit(samp[feats].values)
    km = KMeans(k, n_init=10, random_state=SEED).fit(sc.transform(samp[feats].values))
    df["cl"] = km.predict(sc.transform(X))
    y = df[label_col].values
    ylev = np.unique(y); ymap = {v: i for i, v in enumerate(ylev)}
    yi = np.array([ymap[v] for v in y])
    runs = df.cell.values
    ur = np.unique(runs)
    T_run = {r: table(yi[runs == r], df.cl.values[runs == r], len(ylev), k) for r in ur}
    O_run = {r: table(yi[runs == r], df.oracle.values[runs == r], len(ylev), 2) for r in ur}
    tot = sum(T_run.values()); toto = sum(O_run.values())
    ari_all = ari_from_table(tot); ari_or = ari_from_table(toto) if oracle else np.nan
    rng = np.random.default_rng(rng_seed)
    bs, bo = [], []
    for _ in range(B_RES):
        pick = rng.integers(0, len(ur), len(ur))
        Tb = sum(T_run[ur[i]] for i in pick); Ob = sum(O_run[ur[i]] for i in pick)
        bs.append(ari_from_table(Tb)); bo.append(ari_from_table(Ob) if oracle else np.nan)
    per = []
    for r in ur:
        m = runs == r
        a = adjusted_rand_score(yi[m], df.cl.values[m]) if len(set(yi[m])) > 1 else np.nan
        o = adjusted_rand_score(yi[m], df.oracle.values[m]) if (oracle and len(set(yi[m])) > 1) else np.nan
        per.append(dict(analysis=name, cell=r, windows=int(m.sum()), ARI=a, ARI_best_possible=o))
    per = pd.DataFrame(per)
    ok = per.dropna(subset=["ARI_best_possible"])
    within = int(((ok.ARI_best_possible - ok.ARI) <= 0.05).sum()) if oracle else np.nan
    row = dict(analysis=name, features=", ".join(feats), k=k, windows=len(df), runs=len(ur), ARI_all_windows=ari_all,
               CI_low=np.nanpercentile(bs, 2.5), CI_high=np.nanpercentile(bs, 97.5),
               best_possible_ARI=ari_or, best_CI_low=np.nanpercentile(bo, 2.5) if oracle else np.nan, best_CI_high=np.nanpercentile(bo, 97.5) if oracle else np.nan,
               runs_within_0p05_of_best=within, runs_with_best=len(ok) if oracle else np.nan,
               per_run_ARI_min=per.ARI.min(), per_run_ARI_median=per.ARI.median(), per_run_ARI_max=per.ARI.max())
    return row, per, df


XL = ["RSSI_mean", "RSSI_var", "RSSI_Hop_Diff"]
rows, pers = [], []
jobs = [("blackhole, non-attacker boards, REDUCED, k=2", ch[ch.kind == "blackhole"], REDUCED, 2, "Label", True),
        ("blackhole, non-attacker boards, REDUCED without PDR, k=2", ch[ch.kind == "blackhole"], NOPDR, 2, "Label", True),
        ("wormhole, non-attacker boards, REDUCED, k=2", ch[ch.kind == "wormhole"], REDUCED, 2, "Label", False),
        ("wormhole, non-attacker boards, REDUCED without PDR, k=2", ch[ch.kind == "wormhole"], NOPDR, 2, "Label", False),
        ("pooled 80 runs, REDUCED, k=3 (three labels)", ch, REDUCED, 3, "Label", True),
        ("pooled 80 runs, REDUCED without PDR, k=3 (three labels)", ch, NOPDR, 3, "Label", True),
        ("pooled 80 runs, REDUCED, k=2 (three labels)", ch, REDUCED, 2, "Label", True),
        ("pooled 72 attack runs, REDUCED, k=3 (three labels)", ch[ch.kind != "benign"], REDUCED, 3, "Label", True)]
for name, df, feats, k, lab, orc in jobs:
    r, p, _ = analyse(name, df, feats, k, lab, orc)
    rows.append(r); pers.append(p); print(name, {a: (round(b, 3) if isinstance(b, float) else b) for a, b in r.items() if a not in ("analysis", "features")}, flush=True)

# wormhole tunnel ends: the same check (the oracle of an end is every attack window, so the best possible ARI is 1)
for nm, role, extra in (("exit end A", "wormhole_a", ["TunnelIntensity"]), ("entry end B", "wormhole_b", ["TunnelIntensity"])):
    d = raw[(raw.kind == "wormhole") & (raw.node_role == role) & raw.Label.notna()].dropna(subset=XL + extra).copy()
    d["Label"] = d.Label.astype(int); d["oracle"] = (d.Label == 2).astype(int)
    for feats, tag in ((XL, "cross-layer"), (XL + extra, "cross-layer + TunnelIntensity")):
        r, p, _ = analyse(f"{nm}, {tag}, k=2", d, feats, 2, "Label", True)
        rows.append(r); pers.append(p); print(r["analysis"], round(r["ARI_all_windows"], 3), round(r["CI_low"], 3), round(r["CI_high"], 3), "best", round(r["best_possible_ARI"], 3), flush=True)

pd.DataFrame(rows).to_csv(CSV + "/boot_summary.csv", index=False)
pd.concat(pers).to_csv(CSV + "/boot_per_run.csv", index=False)
print("done")
