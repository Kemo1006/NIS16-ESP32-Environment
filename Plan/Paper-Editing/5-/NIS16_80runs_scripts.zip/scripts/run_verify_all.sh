#!/bin/bash
# Run the repo's own verifier (tools/verify_attack.py) on every planned cell. Run from the repo folder (ESP32-Environment/).
# Do NOT use python3 -I here: isolated mode hides tools/attack_checks.py and the setup checks are skipped.
OUT=${1:-./verify_out}; mkdir -p "$OUT"
export PYTHONUTF8=1
run() { # attack topology location scenario analysis_attack_flag
  python3 tools/verify_attack.py datasets/analysis/$1/$2/$3/$4/feature_table.csv --attack $5 > "$OUT/verify_${1}_${2}_${3}_${4}.txt" 2>&1
}
for a in blackhole wormhole; do for t in linear partial_mesh star tree; do for l in G402 DLSU_Library Yuchengco; do for s in stationary burst highload; do
  run $a $t $l $s $a &
  while [ $(jobs -r | wc -l) -ge 6 ]; do sleep 0.5; done
done; done; done; done
while read t l s; do run baseline $t $l $s none & done <<'LIST'
linear G402 highload
linear DLSU_Library stationary
linear Yuchengco stationary
partial_mesh G402 highload
star G402 burst
star DLSU_Library stationary
star Yuchengco highload
tree G402 stationary
LIST
wait
