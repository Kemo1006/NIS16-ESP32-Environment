"""Collects every result table of the final analysis (80 runs) into one Excel workbook, one sheet per CSV, with an index sheet and a README.
Run: python3 an_assemble.py   (reads out/csv/*.csv, writes ../deliver/NIS16_80runs_analysis_tables.xlsx)"""
import os, glob, re
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

HERE = os.path.dirname(os.path.abspath(__file__))
CSV = os.path.join(HERE, '..', 'out', 'csv')
OUT = os.path.join(HERE, '..', '..', 'deliver', 'NIS16_80runs_analysis_tables.xlsx')

DESC = {
 'inv': 'Inventory of the 80 runs: runs, windows by kind and phase, recaptures, off-plan captures, feature coverage',
 'verify': 'Output of tools/verify_attack.py for every run: grade, attack checks, topology check',
 'bht': 'Blackhole: attack checks per topology, misses, ARI ceiling per group',
 'bh': 'Blackhole analysis: per-cell summary, collapse and recovery, effect sizes, correlations, leakage audit, clustering',
 'wh': 'Wormhole analysis: per-run results, 3-sigma checks, tunnel latency, effect sizes, leakage audit, clustering (wh_cl_*)',
 'ben': 'Benign runs: per-run and per-board PDR, comparison with the normal windows of attack runs, cooldown vs baseline',
 'cl3': 'Pooled three-label clustering of the 80 runs (benign, blackhole, wormhole) and of the 72 attack runs',
 'boot': 'Run-level bootstrap of the K-Means result',
 'facts': 'Supporting numbers quoted in Chapter 6',
}
README = [
 ['NIS16 ESP32 ESP-WIFI-MESH dataset: analysis tables of the 80 runs (36 blackhole, 36 wormhole, 8 benign)'],
 [''],
 ['What this is', 'Every sheet is one result file written by the analysis scripts (scripts zip). The index sheet lists the sheets and the source file names. Numbers in Chapter 6 are read from these tables.'],
 ['Labels', '0 = baseline and cooldown (normal), 1 = blackhole attack, 2 = wormhole attack. pre_baseline, transition and no_phase windows are dropped. Phases are aligned per board because the boards have separate clocks.'],
 ['Exposure', 'Blackhole: downstream = victim, upstream = bystander. Wormhole: entry end B, exit end A, and the five other boards.'],
 ['Windows', '456,195 windows in total (blackhole 212,419; wormhole 207,025; benign 36,751). Analysed: 369,678 (266,491 normal and 103,187 attack).'],
 ['Caveats', 'Benign star/Yuchengco/highload has 6 boards, blackhole tree/G402/highload has 7 boards (one board without data, graded UNDETERMINED). 15 captures were replaced in 11 cells; 12 captures lie outside the plan.'],
 ['Caveats', 'LatencyHopRatio and TunnelLatency carry the label in their missingness; single-feature accuracies are therefore compared with the majority rate among the windows that have a value (see bh_leakage_audit, wh_leakage_audit).'],
 ['Caveats', 'RetryRate on the wormhole entry end B counts tunnelled frames (artefact) and is excluded from the feature sets.'],
 ['Caveats', 'MacRetryRate exists in 7 blackhole runs only and is supplementary.'],
 ['Clustering', 'Five algorithms, k = 2..8, seeds 42/7/123, samples of 6,000 windows, standardised features. ARI and purity are computed against the label after clustering.'],
]


def prefix(name):
    for p in ('verify', 'inv', 'bht', 'boot', 'facts', 'cl3', 'ben', 'bh', 'wh'):
        if name.startswith(p + '_') or name == p: return p
    return 'facts'


def main():
    wb = Workbook()
    ws = wb.active; ws.title = 'README'
    for r in README: ws.append(r)
    ws['A1'].font = Font(bold=True, size=13)
    ws.column_dimensions['A'].width = 16; ws.column_dimensions['B'].width = 150
    for row in ws.iter_rows(min_row=3):
        for c in row: c.alignment = Alignment(wrap_text=True, vertical='top')
        row[0].font = Font(bold=True)
    idx = wb.create_sheet('Index')
    idx.append(['Sheet', 'Source file', 'Rows', 'Columns', 'Group'])
    files = sorted(glob.glob(os.path.join(CSV, '*.csv')))
    used = set()
    hdr = PatternFill('solid', fgColor='DDE6F0')
    for fp in files:
        base = os.path.basename(fp)[:-4]
        if 'smoke' in fp: continue
        d = pd.read_csv(fp)
        nm = re.sub(r'[\[\]\*\?/\\:]', '_', base)[:31]
        k = 1
        while nm in used:
            nm = nm[:28] + '_%d' % k; k += 1
        used.add(nm)
        s = wb.create_sheet(nm)
        s.append(list(map(str, d.columns)))
        for row in d.itertuples(index=False):
            s.append([None if (isinstance(v, float) and v != v) else v for v in row])
        for c in s[1]:
            c.font = Font(bold=True); c.fill = hdr; c.alignment = Alignment(wrap_text=True, vertical='top')
        s.freeze_panes = 'A2'
        for i, col in enumerate(d.columns, 1):
            w = max([len(str(col))] + [len(str(v)) for v in d[col].head(200)])
            s.column_dimensions[get_column_letter(i)].width = min(max(10, w + 2), 60)
        idx.append([nm, base + '.csv', len(d), len(d.columns), DESC[prefix(base)]])
    for c in idx[1]: c.font = Font(bold=True); c.fill = hdr
    idx.column_dimensions['A'].width = 34; idx.column_dimensions['B'].width = 46; idx.column_dimensions['E'].width = 110
    idx.freeze_panes = 'A2'
    wb.save(OUT)
    print('wrote', OUT, len(used), 'sheets')


main()
