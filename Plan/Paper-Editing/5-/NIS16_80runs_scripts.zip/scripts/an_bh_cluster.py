"""Blackhole (no jitter) clustering per the paper's Section 4.2.5 plan.
Five algorithms (DBSCAN primary, K-Means, Ward, GMM, Spectral), standardised features (Eq. 4.18),
k = 2..8, seeds 42/7/123, FULL + REDUCED feature sets (+ a diagnostic set without PDR),
internal metrics (silhouette, Davies-Bouldin) and post-hoc external (purity, ARI).
Run:  python3 an_bh_cluster.py   (do not use -I: cfg.py is imported from this folder)
"""
import os, sys, time, warnings, math
import numpy as np, pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans, DBSCAN, AgglomerativeClustering, SpectralClustering
from sklearn.mixture import GaussianMixture
from sklearn.metrics import silhouette_score, davies_bouldin_score, adjusted_rand_score
from sklearn.neighbors import NearestNeighbors
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE

warnings.filterwarnings("ignore")
from cfg import *
import leakage
O = CSV; OF = FIG
NOTE = f"Blackhole · 36 runs · THESIS3 @ {COMMIT} (24 Oct 2026)"
C_BASE, C_ATT, C_GREY = "#2b6cb0", "#c53030", "#a0aec0"
plt.rcParams.update({"figure.dpi": 130, "savefig.dpi": 160, "font.size": 9,
                     "axes.spines.top": False, "axes.spines.right": False,
                     "axes.titlesize": 10, "axes.titleweight": "bold"})
SEEDS = [42, 7, 123]
KS = list(range(2, 9))
N_SAMPLE = 6000
if os.environ.get("SMOKE"):                      # quick end-to-end test of every stage, tiny sizes, separate folder
    SEEDS, KS, N_SAMPLE = [42, 7], [2, 3], 500
    O = O + "/smoke"; OF = OF + "/smoke"; os.makedirs(O, exist_ok=True); os.makedirs(OF, exist_ok=True)

u = pd.read_pickle(PKL + "/bh_use.pkl")
ch = u[(u.node_role == "child") & u.Label.notna()].copy()
ch["y"] = (ch.Label > 0).astype(int)

# ------------------------------------------------------------------ feature-set construction (rule-based, from the repo's own audit)
aud = leakage.single_feature_decidability(ch, candidates=leakage.TABLE_4_11_FEATURES)
allowed, excluded = leakage.split_columns(ch)
cov = ch[leakage.TABLE_4_11_FEATURES].notna().mean()
dropped = {}
cands = []
for f in allowed:
    row = aud[aud.feature == f].iloc[0]
    if cov[f] < .5:
        dropped[f] = f"only {cov[f]:.0%} populated on child nodes (role-specific)"
    elif row.nan_accuracy > .85:
        dropped[f] = f"'is it missing?' alone predicts the label {row.nan_accuracy:.0%} (undefined when nothing is delivered)"
    else:
        cands.append(f)
for f, why in excluded.items():
    dropped[f] = "leakage.py: excluded"
print("FULL candidates:", cands)
print("dropped:", dropped)

work = ch.dropna(subset=cands).copy()
print(f"complete rows {len(work):,} of {len(ch):,} child windows ({len(ch) - len(work):,} dropped for NaN in the candidates)")

# low variance (>90 % identical) then |r| > 0.85
lowvar = [f for f in cands if work[f].round(6).value_counts(normalize=True).iloc[0] > .90]
keep = [f for f in cands if f not in lowvar]
corr = work[keep].corr(method="pearson").abs()
drop_corr = []
for i, a in enumerate(keep):
    for b in keep[i + 1:]:
        if a not in drop_corr and b not in drop_corr and corr.loc[a, b] > .85:
            drop_corr.append(b)
REDUCED = [f for f in keep if f not in drop_corr]
FULL = cands
NOPDR = [f for f in REDUCED if f != "PDR"]
SETS = {"FULL": FULL, "REDUCED": REDUCED, "REDUCED_no_PDR": NOPDR}
print({k: v for k, v in SETS.items()}, "lowvar:", lowvar, "corr-dropped:", drop_corr)
pd.DataFrame([{"set": k, "n_features": len(v), "features": ", ".join(v)} for k, v in SETS.items()]).to_csv(O + "/bh_cluster_feature_sets.csv", index=False)
pd.DataFrame([{"feature": k, "reason": v} for k, v in dropped.items()] +
             [{"feature": f, "reason": "low variance (>90 % identical values)"} for f in lowvar] +
             [{"feature": f, "reason": "|r| > 0.85 with a kept feature"} for f in drop_corr]).to_csv(O + "/bh_cluster_features_removed.csv", index=False)

# ------------------------------------------------------------------ helpers
def purity(y, c):
    df = pd.DataFrame({"y": y, "c": c})
    return df.groupby("c").y.agg(lambda s: s.value_counts().iloc[0]).sum() / len(df)

def knee(sorted_d):
    x = np.arange(len(sorted_d), dtype=float)
    y = sorted_d.astype(float)
    xn, yn = (x - x.min()) / (x.max() - x.min()), (y - y.min()) / (y.max() - y.min() + 1e-12)
    d = xn - yn            # distance below the chord of a convex rising curve
    return float(y[int(np.argmax(d))])

def internal(X, lab):
    m = lab != -1
    if len(set(lab[m])) < 2 or m.sum() < 10:
        return np.nan, np.nan
    return silhouette_score(X[m], lab[m]), davies_bouldin_score(X[m], lab[m])

def external(y, lab, vic_mask):
    out = {}
    for tag, mask in (("all", np.ones(len(y), bool)), ("victims", vic_mask)):
        out[f"purity_{tag}"] = purity(y[mask], lab[mask])
        out[f"ARI_{tag}"] = adjusted_rand_score(y[mask], lab[mask])
        out[f"majority_{tag}"] = max(y[mask].mean(), 1 - y[mask].mean())
    return out

def fit(algo, X, k, seed):
    if algo == "KMeans": return KMeans(k, n_init=10, random_state=seed).fit_predict(X)
    if algo == "Ward": return AgglomerativeClustering(k, linkage="ward").fit_predict(X)
    if algo == "GMM": return GaussianMixture(k, covariance_type="full", random_state=seed, reg_covar=1e-4).fit(X).predict(X)
    if algo == "Spectral": return SpectralClustering(k, affinity="nearest_neighbors", n_neighbors=15, random_state=seed).fit_predict(X)
    raise ValueError(algo)

def dbscan_search(X, D, seed):
    best, log = None, []
    for ms in sorted({D + 1, int(math.ceil(1.5 * D)), 2 * D}):
        nn = NearestNeighbors(n_neighbors=ms).fit(X)
        kd = np.sort(nn.kneighbors(X)[0][:, -1])
        eps = max(knee(kd), 1e-3)
        lab = DBSCAN(eps=eps, min_samples=ms).fit_predict(X)
        ncl = len(set(lab)) - (1 if -1 in lab else 0)
        noise = float((lab == -1).mean())
        sil, db = internal(X, lab)
        log.append(dict(min_samples=ms, eps=eps, clusters=ncl, noise=noise, silhouette=sil, DB=db))
        key = (-(sil if np.isfinite(sil) else -9)) if noise < .5 else 9
        if best is None or key < best[0]:
            best = (key, ms, eps, lab, kd)
    return best, log

# ------------------------------------------------------------------ main sweep
pops = {"all child nodes": None, "victims only": "downstream"}
rows, dbrows, assign_store = [], [], {}
t0 = time.time()
for pop, expo in pops.items():
    base = work if expo is None else work[work.exposure == expo]
    for seed in SEEDS:
        samp = base.sample(min(N_SAMPLE, len(base)), random_state=seed)
        y = samp.y.values
        vic = (samp.exposure == "downstream").values
        for sname, feats in SETS.items():
            X = StandardScaler().fit_transform(samp[feats].values)           # Equation 4.18
            D = X.shape[1]
            # DBSCAN
            (key, ms, eps, lab, kd), log = dbscan_search(X, D, seed)
            for l in log: dbrows.append(dict(population=pop, seed=seed, feature_set=sname, **l))
            sil, db = internal(X, lab)
            ncl = len(set(lab)) - (1 if -1 in lab else 0)
            rows.append(dict(population=pop, feature_set=sname, algorithm="DBSCAN", k=ncl, seed=seed, silhouette=sil, DB=db,
                             noise=float((lab == -1).mean()), eps=eps, min_samples=ms, **external(y, lab, vic)))
            if seed == 42:
                assign_store[(pop, sname, "DBSCAN")] = (samp.index.values, lab, kd, eps)
            for algo in ("KMeans", "Ward", "GMM", "Spectral"):
                for k in KS:
                    lab = fit(algo, X, k, seed)
                    sil, db = internal(X, lab)
                    rows.append(dict(population=pop, feature_set=sname, algorithm=algo, k=k, seed=seed, silhouette=sil, DB=db,
                                     noise=0.0, eps=np.nan, min_samples=np.nan, **external(y, lab, vic)))
                    if seed == 42 and algo == "KMeans" and k in (2, 3, 4):
                        assign_store[(pop, sname, f"KMeans{k}")] = (samp.index.values, lab, None, None)
        print(f"  {pop} seed {seed} done  ({time.time() - t0:.0f}s)", flush=True)

res = pd.DataFrame(rows)
res.to_csv(O + "/bh_clustering_all_runs.csv", index=False)
pd.DataFrame(dbrows).to_csv(O + "/bh_dbscan_parameter_search.csv", index=False)
import pickle
pickle.dump(assign_store, open(PKL + "/bh_assign_store.pkl", "wb"))        # so a crash below never costs the 13-minute sweep again

METRICS = ["silhouette", "DB", "purity_all", "ARI_all", "purity_victims", "ARI_victims", "majority_all", "majority_victims", "noise"]
mk = res[res.algorithm != "DBSCAN"]
agg = mk.groupby(["population", "feature_set", "algorithm", "k"])[METRICS].mean().reset_index()
agg_sd = (mk.groupby(["population", "feature_set", "algorithm", "k"])[["silhouette", "ARI_all", "ARI_victims"]].std().reset_index()
          .rename(columns={"silhouette": "sil_sd", "ARI_all": "ARI_all_sd", "ARI_victims": "ARI_victims_sd"}))
agg = agg.merge(agg_sd, on=["population", "feature_set", "algorithm", "k"])
# DBSCAN picks its own k per seed, so average per (population, feature set) instead of per k
db = res[res.algorithm == "DBSCAN"]
dbagg = db.groupby(["population", "feature_set", "algorithm"]).agg(
    k=("k", "mean"), k_per_seed=("k", lambda s: "/".join(str(int(v)) for v in s)),
    **{m: (m, "mean") for m in METRICS}).reset_index()
dbagg["k_per_seed"] = dbagg["k_per_seed"].astype(str)
pd.concat([agg, dbagg]).to_csv(O + "/bh_clustering_mean_over_seeds.csv", index=False)

# best-k by silhouette (the paper's internal criterion) and k = 2 (normal vs anomalous)
best_rows = []
for _, g in agg.groupby(["population", "feature_set", "algorithm"]):
    g = g.dropna(subset=["silhouette"])
    if len(g): best_rows.append(g.loc[g.silhouette.idxmax()])
best = pd.DataFrame(best_rows); best["selection"] = "best silhouette"
k2 = agg[agg.k == 2].copy(); k2["selection"] = "k = 2"
dbs = dbagg.copy(); dbs["selection"] = "DBSCAN (own k)"
summary = pd.concat([best, k2, dbs]).sort_values(["population", "feature_set", "algorithm", "selection"])
summary.to_csv(O + "/bh_clustering_summary.csv", index=False)
pd.set_option("display.width", 250)
print(summary[["population", "feature_set", "algorithm", "selection", "k", "silhouette", "DB", "purity_all", "majority_all", "ARI_all", "purity_victims", "ARI_victims", "noise"]].round(3).to_string())

# ------------------------------------------------------------------ sensitivity 1: cooldown windows removed from the label (baseline vs attack only)
srows = []
nocd = work[work.segment != "cooldown"]
for seed in SEEDS:
    samp = nocd.sample(min(N_SAMPLE, len(nocd)), random_state=seed)
    y = samp.y.values; vic = (samp.exposure == "downstream").values
    for sname, feats in SETS.items():
        X = StandardScaler().fit_transform(samp[feats].values)
        for k in (2, 3):
            lab = KMeans(k, n_init=10, random_state=seed).fit_predict(X)
            sil, dbi = internal(X, lab)
            srows.append(dict(variant="cooldown removed", feature_set=sname, algorithm="KMeans", k=k, seed=seed, silhouette=sil, DB=dbi, **external(y, lab, vic)))
        (_, ms, eps, lab, _), _ = dbscan_search(X, X.shape[1], seed)
        sil, dbi = internal(X, lab)
        srows.append(dict(variant="cooldown removed", feature_set=sname, algorithm="DBSCAN", k=len(set(lab)) - (1 if -1 in lab else 0),
                          seed=seed, silhouette=sil, DB=dbi, **external(y, lab, vic)))
# ------------------------------------------------------------------ sensitivity 2: K-Means k = 2 inside each site and each topology
for dim in ("location", "topology"):
    for val, base in work.groupby(dim):
        for seed in SEEDS:
            samp = base.sample(min(4000, len(base)), random_state=seed)
            y = samp.y.values; vic = (samp.exposure == "downstream").values
            for sname, feats in SETS.items():
                X = StandardScaler().fit_transform(samp[feats].values)
                lab = KMeans(2, n_init=10, random_state=seed).fit_predict(X)
                sil, dbi = internal(X, lab)
                srows.append(dict(variant=f"within {dim} = {val}", feature_set=sname, algorithm="KMeans", k=2, seed=seed,
                                  silhouette=sil, DB=dbi, **external(y, lab, vic)))
sens = pd.DataFrame(srows)
sens.to_csv(O + "/bh_clustering_sensitivity_runs.csv", index=False)
sens_s = sens.groupby(["variant", "feature_set", "algorithm", "k"])[["silhouette", "DB", "purity_all", "ARI_all", "purity_victims", "ARI_victims", "majority_all"]].mean().reset_index()
sens_s.to_csv(O + "/bh_clustering_sensitivity.csv", index=False)
print(sens_s.round(3).to_string())

# ------------------------------------------------------------------ cluster profiles (seed 42, k = 2 and 3, FULL / REDUCED / no-PDR)
prof = []
for (pop, sname, tag), (idx, lab, _, _) in assign_store.items():
    if not tag.startswith("KMeans"): continue
    d = work.loc[idx].copy(); d["cluster"] = lab
    feats = SETS[sname]
    for c, g in d.groupby("cluster"):
        r = dict(population=pop, feature_set=sname, model=tag, cluster=c, n=len(g), attack_share=g.y.mean(),
                 victim_share=(g.exposure == "downstream").mean(), baseline_share=(g.segment == "baseline").mean(),
                 attack_phase_share=(g.segment == "attack").mean(), cooldown_share=(g.segment == "cooldown").mean())
        for f in leakage.TABLE_4_11_FEATURES:
            if f in work.columns and f in feats: r["mean_" + f] = g[f].mean()
        prof.append(r)
pd.DataFrame(prof).to_csv(O + "/bh_cluster_profiles_kmeans.csv", index=False)

# ------------------------------------------------------------------ figures
algos = ["KMeans", "Ward", "GMM", "Spectral"]
cols = {"KMeans": "#2b6cb0", "Ward": "#2f855a", "GMM": "#805ad5", "Spectral": "#dd6b20"}

def sweep_fig(metric, ylabel, fname, title, pop_list, sets_list, sd_col=None, hline=None):
    fig, axes = plt.subplots(len(sets_list), len(pop_list), figsize=(5.2 * len(pop_list), 2.9 * len(sets_list)), sharex=True, squeeze=False)
    for i, sname in enumerate(sets_list):
        for j, pop in enumerate(pop_list):
            ax = axes[i, j]
            for a in algos:
                g = agg[(agg.population == pop) & (agg.feature_set == sname) & (agg.algorithm == a)].sort_values("k")
                sd = res[(res.population == pop) & (res.feature_set == sname) & (res.algorithm == a)].groupby("k")[metric].std().reindex(g.k).values
                ax.errorbar(g.k, g[metric], yerr=sd, label=a, color=cols[a], marker="o", ms=3, lw=1.3, capsize=2)
            d = dbagg[(dbagg.population == pop) & (dbagg.feature_set == sname)]
            if len(d) and np.isfinite(d[metric].iloc[0]):
                ax.axhline(d[metric].iloc[0], color="#444", ls=":", lw=1, label=f"DBSCAN (k per seed {d.k_per_seed.iloc[0]})")
            if hline is not None: ax.axhline(hline, color=C_GREY, lw=.8)
            ax.set_title(f"{sname} ({len(SETS[sname])} feat.) · {pop}", fontsize=8.5)
            ax.set_ylabel(ylabel)
            if i == len(sets_list) - 1: ax.set_xlabel("k (number of clusters)")
    axes[0, 0].legend(frameon=False, fontsize=7, ncol=2)
    fig.suptitle(title, fontweight="bold", y=1.0)
    fig.text(0.01, -0.01, NOTE + f" · mean ± sd over seeds {SEEDS}, n = {N_SAMPLE:,} windows per seed", fontsize=7, color=C_GREY)
    fig.tight_layout(); fig.savefig(OF + "/bh_" + fname, bbox_inches="tight"); plt.close(fig)

sweep_fig("ARI_all", "ARI vs attack/normal label", "fig7_cluster_ARI_vs_k.png",
          "Does clustering recover the attack phase?  Adjusted Rand Index vs k", list(pops), list(SETS), hline=0)
sweep_fig("silhouette", "silhouette", "fig8a_cluster_silhouette_vs_k.png",
          "Internal quality: silhouette vs k (higher = better separated)", list(pops), list(SETS))
sweep_fig("DB", "Davies–Bouldin", "fig8b_cluster_DB_vs_k.png",
          "Internal quality: Davies–Bouldin vs k (lower = better separated)", list(pops), list(SETS))

# DBSCAN k-distance + result
fig, axes = plt.subplots(1, 3, figsize=(12, 3.4))
for ax, sname in zip(axes, SETS):
    idx, lab, kd, eps = assign_store[("all child nodes", sname, "DBSCAN")]
    ax.plot(kd, color="#2b6cb0"); ax.axhline(eps, color=C_ATT, ls="--", lw=1)
    ncl = len(set(lab)) - (1 if -1 in lab else 0)
    ax.set_title(f"{sname}: eps = {eps:.2f} → {ncl} cluster(s), {np.mean(lab == -1):.0%} noise", fontsize=8.5)
    ax.set_xlabel("points sorted by k-distance"); ax.set_ylabel("k-distance")
fig.suptitle("DBSCAN k-distance graphs (Table 4.19 procedure), all child nodes, seed 42", fontweight="bold", y=1.02)
fig.text(0.01, -0.04, NOTE, fontsize=7, color=C_GREY)
fig.tight_layout(); fig.savefig(OF + "/bh_fig9_dbscan_kdistance.png", bbox_inches="tight"); plt.close(fig)

# PCA / t-SNE of the standardised FULL set (seed 42 sample, all child nodes)
samp = work.sample(N_SAMPLE, random_state=42)
Xf = StandardScaler().fit_transform(samp[FULL].values)
pc = PCA(2, random_state=42).fit(Xf); Z = pc.transform(Xf)
ts = TSNE(2, perplexity=40, random_state=42, init="pca").fit_transform(Xf)
phase = np.where(samp.exposure == "downstream", np.where(samp.y == 1, "victim · attack", "victim · normal"),
                 np.where(samp.y == 1, "not behind · attack", "not behind · normal"))
pal = {"victim · attack": C_ATT, "victim · normal": "#f6ad55", "not behind · attack": "#63b3ed", "not behind · normal": "#2b6cb0"}
fig, axes = plt.subplots(1, 2, figsize=(11, 4.6))
for ax, E, nm in ((axes[0], Z, f"PCA (PC1 {pc.explained_variance_ratio_[0]:.0%}, PC2 {pc.explained_variance_ratio_[1]:.0%})"), (axes[1], ts, "t-SNE (perplexity 40)")):
    for k_, c in pal.items():
        m = phase == k_
        ax.scatter(E[m, 0], E[m, 1], s=4, alpha=.45, color=c, label=k_, lw=0)
    ax.set_title(nm)
axes[0].legend(markerscale=3, frameon=False, fontsize=8)
fig.suptitle(f"Standardised FULL feature set ({len(FULL)} features), {N_SAMPLE:,} child-node windows", fontweight="bold")
fig.text(0.01, -0.02, NOTE, fontsize=7, color=C_GREY)
fig.tight_layout(); fig.savefig(OF + "/bh_fig10_pca_tsne_full.png", bbox_inches="tight"); plt.close(fig)
ld = pd.DataFrame(pc.components_.T, index=FULL, columns=["PC1", "PC2"]); ld.to_csv(O + "/bh_pca_loadings_full.csv")

# t-SNE / PCA without PDR (cross-layer only)
Xn = StandardScaler().fit_transform(samp[NOPDR].values)
pcn = PCA(2, random_state=42).fit(Xn); Zn = pcn.transform(Xn)
tsn = TSNE(2, perplexity=40, random_state=42, init="pca").fit_transform(Xn)
fig, axes = plt.subplots(1, 2, figsize=(11, 4.6))
for ax, E, nm in ((axes[0], Zn, f"PCA (PC1 {pcn.explained_variance_ratio_[0]:.0%}, PC2 {pcn.explained_variance_ratio_[1]:.0%})"), (axes[1], tsn, "t-SNE (perplexity 40)")):
    for k_, c in pal.items():
        m = phase == k_
        ax.scatter(E[m, 0], E[m, 1], s=4, alpha=.45, color=c, label=k_, lw=0)
    ax.set_title(nm)
axes[0].legend(markerscale=3, frameon=False, fontsize=8)
fig.suptitle(f"Same windows with the delivery ratio removed: {', '.join(NOPDR)}", fontweight="bold")
fig.text(0.01, -0.02, NOTE, fontsize=7, color=C_GREY)
fig.tight_layout(); fig.savefig(OF + "/bh_fig11_pca_tsne_without_pdr.png", bbox_inches="tight"); plt.close(fig)

# cluster composition, K-Means k=2/3, all child nodes, three feature sets
fig, axes = plt.subplots(1, 3, figsize=(12, 3.8), sharey=True)
for ax, sname in zip(axes, SETS):
    idx, lab, _, _ = assign_store[("all child nodes", sname, "KMeans3")]
    d = work.loc[idx].copy(); d["cluster"] = lab
    d["grp"] = np.where(d.exposure == "downstream", np.where(d.y == 1, "victim · attack", "victim · normal"),
                        np.where(d.y == 1, "not behind · attack", "not behind · normal"))
    ct = pd.crosstab(d.cluster, d.grp, normalize="index")
    n = d.cluster.value_counts().sort_index()
    bottom = np.zeros(len(ct))
    for g_ in ["victim · attack", "not behind · attack", "victim · normal", "not behind · normal"]:
        if g_ in ct:
            ax.bar([f"C{c}\n(n={n[c]:,})" for c in ct.index], ct[g_], bottom=bottom, color=pal[g_], label=g_)
            bottom += ct[g_].values
    ax.set_title(f"{sname}, K-Means k = 3")
axes[0].set_ylabel("share of the cluster")
axes[0].legend(frameon=False, fontsize=7, loc="lower left")
fig.suptitle("What is inside each cluster (all child nodes, seed 42)", fontweight="bold", y=1.02)
fig.text(0.01, -0.04, NOTE, fontsize=7, color=C_GREY)
fig.tight_layout(); fig.savefig(OF + "/bh_fig12_cluster_composition.png", bbox_inches="tight"); plt.close(fig)

# listwise deletion check (what the repo's default row-drop would do to victim attack windows)
lh = ch[(ch.exposure == "downstream") & (ch.segment == "attack")]
lost = lh.LatencyHopRatio.isna().mean()
pd.DataFrame([dict(item="victim attack windows with LatencyHopRatio undefined", value=lost, n=len(lh))]).to_csv(O + "/bh_listwise_deletion_check.csv", index=False)
print(f"victim attack windows with LatencyHopRatio undefined: {lost:.1%}")
print("done", f"{time.time() - t0:.0f}s")
