"""Step 2. Parse the verifier reports (tools/verify_attack.py output, one text file per run) into verify_summary.csv.
Run the verifier first:  run_verify_all.sh <outdir>   (from the repository folder)"""
import re, glob, os
import pandas as pd, numpy as np
from cfg import *

def num(x):
    x = x.strip()
    if x in ("+inf", "inf"): return np.inf
    if x == "-inf": return -np.inf
    try: return float(x)
    except Exception: return np.nan

CHECK = re.compile(r"^\s+(PASS|FAIL|EXCLUDED|NO DATA|UNTESTABLE|INFO)\s+(\S.*?)\s{2,}(\S.*?)\s*$", re.M)
rows, checks = [], []
for a, t, l, s in plan_cells():
    kind = {"baseline": "benign"}.get(a, a)
    f = f"{VER}/verify_{a}_{t}_{l}_{s}.txt"
    txt = open(f, encoding="utf-8", errors="replace").read()
    r = dict(kind=kind, topology=t, location=l, scenario=s, cell=f"{kind}/{t}/{l}/{s}")
    r["result"] = (re.search(r"^ RESULT : (.*)$", txt, re.M) or [None, ""])[1].strip()
    r["verdict"] = (re.search(r"^ VERDICT: (.*)$", txt, re.M) or [None, ""])[1].strip()
    conf = (re.search(r"^ CONFIDENCE: (.*)$", txt, re.M) or [None, ""])[1].strip()
    r["confidence_full"] = conf
    r["grade"] = conf.split(" - ")[0].strip()
    r["outcome"] = (re.search(r"^ OUTCOME: (.*)$", txt, re.M) or [None, ""])[1].strip()
    r["scenario_applied"] = "NOT APPLIED" in r["verdict"] and "NOT APPLIED" or ("applied" if "applied" in r["verdict"] else "")
    g = re.search(r"AT A GLANCE:\s+(.*)", txt)
    r["glance"] = re.sub(r"\s+", " ", g.group(1)).strip() if g else ""
    for k in ("SCENARIO", "TOPOLOGY", "VICTIMS", "ATTACKER", "TUNNEL", "START"):
        m = re.search(k + r" \[\s*(OK|WARN|FAIL|--)\s*\]", r["glance"])
        r["glance_" + k.lower()] = m.group(1) if m else ""
    m = re.search(r"normal phase: (\d+) windows\s+attack phase: (\d+) windows", txt)
    r["normal_windows_verifier"], r["attack_windows_verifier"] = (int(m.group(1)), int(m.group(2))) if m else (np.nan, np.nan)
    # notes of the verdict block (lines beginning with '~')
    r["notes"] = " | ".join(re.sub(r"\s+", " ", x).strip() for x in re.findall(r"^\s+~ (?:note: )?(.*(?:\n {7,}\S.*)*)", txt, re.M))
    r["n_notes"] = len(re.findall(r"^\s+~ ", txt.split("VERDICT")[-1], re.M)) if "VERDICT" in txt else 0
    # setup lines
    sec3 = txt.split("[3] SETUP CHECKS")[1].split("[4]")[0] if "[3] SETUP CHECKS" in txt else ""
    r["setup_FAIL"] = len(re.findall(r"^\s+FAIL ", sec3, re.M)); r["setup_WARN"] = len(re.findall(r"^\s+WARN ", sec3, re.M))
    r["setup_notes"] = " | ".join(f"{a_}: {re.sub(chr(10)+' +',' ',b_)[:140]}" for a_, b_ in re.findall(r"^\s+(FAIL|WARN) (.*(?:\n {10,}\S.*)*)", sec3, re.M))
    # layout text (for the depth of the ends)
    lay = re.search(r"LAYOUT AT THE START OF THE ATTACK.*?\n(.*?)\n\n", sec3, re.S)
    r["layout"] = lay.group(1) if lay else ""
    m = re.search(r"UART: B sent ~(\d+) tunnel frames, A received ~(\d+) \((\d+)%\)", sec3)
    r["uart_B_sent"], r["uart_A_recv"], r["uart_pct"] = (int(m.group(1)), int(m.group(2)), int(m.group(3))) if m else (np.nan,) * 3
    m = re.search(r"the root saw duplicate arrivals in (\d+) attack window", sec3)
    r["dup_attack_windows_verifier"] = int(m.group(1)) if m else np.nan
    m = re.search(r"TunnelLatency: the two copies of B's probes reached the root ([\d.]+) ms apart", txt)
    r["tunnel_latency_ms_verifier"] = float(m.group(1)) if m else np.nan
    m = re.search(r"LatencyHopRatio: normal ([\d.]+) \+- ([\d.]+) -> attack ([\d.]+) \(z ([-+\d.]+)\)", txt)
    if m: r["lhr_normal_mean"], r["lhr_normal_sd"], r["lhr_attack_mean"], r["lhr_z"] = map(float, m.groups())
    m = re.search(r"\*\* (\d+) VICTIM\(S\).*Worst attack PDR (\d+\.\d+)", txt)
    r["victims_verifier"], r["worst_victim_pdr"] = (int(m.group(1)), float(m.group(2))) if m else (0, np.nan)
    # score lines
    sec1 = txt.split("[1] ")[1].split("[2]")[0] if "[1] " in txt else ""
    for m in re.finditer(r"^\s+(?:(blackhole|wormhole)\s+)?(PASS|FAIL|EXCLUDED|NO DATA|UNTESTABLE)\s+([A-Za-z]+(?: \(attacker\))?)\s+(.*?)\s+(primary|support|secondary), (up|down)", sec1, re.M):
        sig, status, feat, mid, tier, direction = m.groups()
        mm = re.match(r"(\S+)(?: \+- (\S+))?\s+(\S+)\s+(\S+)$", mid.strip())
        c = dict(cell=r["cell"], kind=kind, topology=t, location=l, scenario=s, signature=sig or kind, feature=feat, status=status, tier=tier, direction=direction, raw=mid.strip())
        if mm:
            c.update(normal_mean=num(mm.group(1)), normal_sd=num(mm.group(2) or "nan"), attack_value=num(mm.group(3)), z=num(mm.group(4)))
        checks.append(c)
        if kind != "benign":
            key = re.sub(r"\W+", "_", feat.replace(" (attacker)", "_att")).lower()
            r["chk_" + key] = status
    rows.append(r)
ver = pd.DataFrame(rows); chk = pd.DataFrame(checks)
ver.to_csv(CSV + "/verify_summary.csv", index=False); chk.to_csv(CSV + "/verify_checks.csv", index=False)
print(ver.groupby(["kind", "grade"]).size())
print(ver.groupby(["kind", "result"]).size())
print(chk.groupby(["kind", "feature", "status"]).size())
print(ver[ver.kind == "wormhole"][["cell", "uart_pct", "dup_attack_windows_verifier", "tunnel_latency_ms_verifier", "glance"]].to_string())
