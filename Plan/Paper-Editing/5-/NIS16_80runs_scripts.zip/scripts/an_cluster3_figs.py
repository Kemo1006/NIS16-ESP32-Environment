"""FIGURES of the pooled three-label clustering (re-runnable from the pickles written by an_cluster3.py). Pooled three-label clustering of the non-attacker boards of all 80 runs (normal 0, blackhole 1, wormhole 2).
Population A: all 80 runs (36 blackhole + 36 wormhole + 8 benign).  Population B (sensitivity): the 72 attack runs without the benign runs.
Same procedure as the blackhole clustering (clu_lib.py). Writes out/csv/cl3_*.csv, out/fig/cl3_fig*.png, pkl/cl3_*.pkl
Run:  OMP_NUM_THREADS=1 python3 an_cluster3.py        (do not use -I)"""
import os, sys, pickle, warnings
import numpy as np, pandas as pd
from cfg import *
from clu_lib import *
import leakage
warnings.filterwarnings("ignore")
plt = mpl()
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
O, OF = CSV, FIG
NOTE = f"Pooled non-attacker boards · 80 runs · THESIS3 @ {COMMIT} · 24 Oct 2026"
if os.environ.get("SMOKE"):
    import clu_lib; SEEDS, KS, N_SAMPLE = [42, 7], [2, 3], 500
    O = O + "/smoke"; OF = OF + "/smoke"; os.makedirs(O, exist_ok=True); os.makedirs(OF, exist_ok=True)

import pickle
work = pd.read_pickle(PKL + "/cl3_work.pkl")
store = pickle.load(open(PKL + "/cl3_assign_store.pkl", "rb"))
S = pickle.load(open(PKL + "/cl3_summary.pkl", "rb"))
res, agg, dbagg, summ, pl = S["res"], S["agg"], S["dbagg"], S["summ"], S["pl"]
GRPS = ["normal · benign run", "normal · blackhole run", "normal · wormhole run",
        "blackhole attack · victim", "blackhole attack · bystander", "wormhole attack · other board"]
GCOL = {"normal · benign run": "#2f855a", "normal · blackhole run": "#2b6cb0", "normal · wormhole run": "#805ad5",
        "blackhole attack · victim": "#c53030", "blackhole attack · bystander": "#f6ad55", "wormhole attack · other board": "#d53f8c"}
# ------------------------------------------------------------------ figures
algos = ["KMeans", "Ward", "GMM", "Spectral"]
cols = {"KMeans": "#2b6cb0", "Ward": "#2f855a", "GMM": "#805ad5", "Spectral": "#dd6b20"}
pops = list(pl)
pl = pops
fig, axes = plt.subplots(3, 2, figsize=(10.4, 8.4), sharex=True)
for i, sname in enumerate(SETS):
    for j, pop in enumerate(pl):
        ax = axes[i, j]
        for a in algos:
            g = agg[(agg.population == pop) & (agg.feature_set == sname) & (agg.algorithm == a)].sort_values("k")
            sd = res[(res.population == pop) & (res.feature_set == sname) & (res.algorithm == a)].groupby("k").ARI.std().reindex(g.k).values
            ax.errorbar(g.k, g.ARI, yerr=sd, label=a, color=cols[a], marker="o", ms=3, lw=1.3, capsize=2)
        d = dbagg[(dbagg.population == pop) & (dbagg.feature_set == sname)]
        if len(d): ax.axhline(d.ARI.iloc[0], color="#444", ls=":", lw=1, label=f"DBSCAN (k per seed {d.k_per_seed.iloc[0]})")
        orc = res[(res.population == pop) & (res.feature_set == sname)].ARI_oracle.mean()
        ax.axhline(orc, color="#c53030", ls="--", lw=.9, label=f"best possible ({orc:.2f})")
        ax.axhline(0, color=C_GREY, lw=.7)
        ax.set_title(f"{sname} · {pop}", fontsize=8.5); ax.set_ylabel("ARI, three labels")
        ax.set_ylim(-0.1, 0.6)
        if i == 2: ax.set_xlabel("k (number of clusters)")
axes[0, 0].legend(frameon=False, fontsize=6.5, ncol=2, loc="upper right")
fig.suptitle("Do normal, blackhole and wormhole windows separate?  ARI against the three labels", fontweight="bold", y=1.0)
fig.text(0.01, -0.01, NOTE + f" · mean ± sd over seeds {SEEDS}, n = {N_SAMPLE:,} per seed", fontsize=7, color=C_GREY)
fig.tight_layout(); fig.savefig(OF + "/cl3_fig1_ARI_vs_k.png", bbox_inches="tight"); plt.close(fig)

# heat maps: share of each kind of window per cluster, and the feature means per cluster (K-Means, seed 42)
def heat(ax, M, rows, cols_, title, fmt="{:.0f}", cmap="Blues", vmin=None, vmax=None, annot=None):
    im = ax.imshow(M, cmap=cmap, aspect="auto", vmin=vmin, vmax=vmax)
    ax.set_xticks(range(len(cols_))); ax.set_xticklabels(cols_, rotation=35, ha="right", fontsize=7.5)
    ax.set_yticks(range(len(rows))); ax.set_yticklabels(rows, fontsize=8)
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            t = (annot[i][j] if annot is not None else fmt.format(M[i, j]))
            v = (M[i, j] - (vmin if vmin is not None else M.min())) / ((vmax if vmax is not None else M.max()) - (vmin if vmin is not None else M.min()) + 1e-12)
            ax.text(j, i, t, ha="center", va="center", fontsize=7.5, color="white" if (abs(v - .5) > .3 if cmap in ("RdBu_r", "RdBu", "coolwarm") else v > .6) else "#1a202c")
    ax.set_title(title, fontsize=9)
    return im

short = {"normal · benign run": "normal\nbenign", "normal · blackhole run": "normal\nblackhole run", "normal · wormhole run": "normal\nwormhole run",
         "blackhole attack · victim": "blackhole\nvictim", "blackhole attack · bystander": "blackhole\nbystander", "wormhole attack · other board": "wormhole\nother board"}
for tagk in ("KMeans3", "KMeans2"):
    fig, axes = plt.subplots(2, 2, figsize=(11.2, 7.4), gridspec_kw={"width_ratios": [1.25, 1]})
    for r_i, sname in enumerate(("REDUCED", "REDUCED_no_PDR")):
        idx, lab, _, _ = store[(pl[0], sname, tagk)]
        d = work.loc[idx].copy(); d["cluster"] = lab
        ns = d.cluster.value_counts().sort_index()
        rows_ = [f"C{c} (n={ns[c]:,})" for c in ns.index]
        # left: what each cluster is made of (row = cluster, the six kinds of window add to 100 % along the row)
        M = np.array([[ (d[d.cluster == c].grp == G).mean() * 100 for G in GRPS] for c in ns.index])
        heat(axes[r_i, 0], M, rows_, [short[G] for G in GRPS], f"{sname}: what each cluster is made of (% of its windows)", fmt="{:.0f}", cmap="Blues", vmin=0, vmax=100)
        # right: mean features per cluster
        feats = SETS[sname]
        Mf = np.array([[d[d.cluster == c][f].mean() for f in feats] for c in ns.index])
        Z = (Mf - d[feats].mean().values) / d[feats].std().values          # colour = the cluster mean in sample SD from the sample mean
        ann = [[(f"{Mf[i, j]:.3f}" if abs(Mf[i, j]) < 10 else f"{Mf[i, j]:.1f}") for j in range(len(feats))] for i in range(len(ns))]
        heat(axes[r_i, 1], Z, rows_, feats, f"{sname}: mean of each feature per cluster", cmap="RdBu_r", vmin=-3, vmax=3, annot=ann)
        axes[r_i, 1].set_yticklabels([])
    fig.suptitle(f"What is inside each cluster of the pooled windows ({tagk.replace('KMeans', 'K-Means k = ')}, seed 42, {pl[0]})", fontweight="bold", y=1.0)
    fig.text(0.01, -0.01, NOTE + " · right panels: colour = cluster mean in standard deviations from the sample mean, number = mean", fontsize=7, color=C_GREY)
    fig.tight_layout(); fig.savefig(OF + f"/cl3_fig2_heatmaps_{tagk}.png", bbox_inches="tight"); plt.close(fig)

# box plots per cluster, K-Means k = 3, REDUCED, seed 42, 80 runs
idx, lab, _, _ = store[(pl[0], "REDUCED", "KMeans3")]
d = work.loc[idx].copy(); d["cluster"] = lab
ns = d.cluster.value_counts().sort_index()
fig, axes = plt.subplots(1, 4, figsize=(11.6, 3.6))
for ax, f in zip(axes, REDUCED):
    data = [d[d.cluster == c][f].values for c in ns.index]
    bp = ax.boxplot(data, tick_labels=[f"C{c}\n(n={ns[c]:,})" for c in ns.index], showfliers=False, patch_artist=True, widths=.55)
    for p, c in zip(bp["boxes"], ["#90cdf4", "#fbb6ce", "#9ae6b4", "#faf089"]): p.set_facecolor(c)
    for m in bp["medians"]: m.set_color("black")
    ax.set_title(f, fontsize=9)
fig.suptitle("Feature values inside each cluster (K-Means k = 3, REDUCED, seed 42, 80 runs)", fontweight="bold", y=1.03)
fig.text(0.01, -0.06, NOTE, fontsize=7, color=C_GREY)
fig.tight_layout(); fig.savefig(OF + "/cl3_fig3_boxplots_per_cluster.png", bbox_inches="tight"); plt.close(fig)

# PCA / t-SNE of the pooled sample (FULL), coloured by the six kinds of window; and without PDR
samp = work.sample(N_SAMPLE, random_state=42)
for tag, feats, fname in (("FULL", FULL, "cl3_fig4_pca_tsne_full.png"), ("without PDR", NOPDR, "cl3_fig5_pca_tsne_without_pdr.png")):
    Xf = StandardScaler().fit_transform(samp[feats].values)
    pc = PCA(2, random_state=42).fit(Xf); Z = pc.transform(Xf)
    ts = TSNE(2, perplexity=40, random_state=42, init="pca").fit_transform(Xf)
    fig, axes = plt.subplots(1, 2, figsize=(11.4, 4.8))
    for ax, E, nm in ((axes[0], Z, f"PCA (PC1 {pc.explained_variance_ratio_[0]:.0%}, PC2 {pc.explained_variance_ratio_[1]:.0%})"), (axes[1], ts, "t-SNE (perplexity 40)")):
        for G in GRPS:
            m = (samp.grp == G).values
            ax.scatter(E[m, 0], E[m, 1], s=4 if "normal" in G else 5, alpha=.5, color=GCOL[G], label=f"{G} ({m.sum():,})", lw=0)
        ax.set_title(nm + (" · axes cut at the 0.5th and 99.5th percentile" if nm.startswith("PCA") else ""), fontsize=9)
        if nm.startswith("PCA"):
            ax.set_xlim(*np.percentile(E[:, 0], [0.5, 99.5])); ax.set_ylim(*np.percentile(E[:, 1], [0.5, 99.5]))
    axes[0].legend(markerscale=3, frameon=False, fontsize=6.8, loc="best")
    fig.suptitle(f"Pooled windows of the 80 runs, standardised {tag} features ({len(feats)}), {N_SAMPLE:,} windows", fontweight="bold")
    fig.text(0.01, -0.02, NOTE, fontsize=7, color=C_GREY)
    fig.tight_layout(); fig.savefig(OF + "/" + fname, bbox_inches="tight"); plt.close(fig)
    if tag == "FULL":
        pd.DataFrame(pc.components_.T, index=feats, columns=["PC1", "PC2"]).assign(var_PC1=pc.explained_variance_ratio_[0], var_PC2=pc.explained_variance_ratio_[1]).to_csv(O + "/cl3_pca_loadings_full.csv")
    else:
        pd.DataFrame(pc.components_.T, index=feats, columns=["PC1", "PC2"]).assign(var_PC1=pc.explained_variance_ratio_[0], var_PC2=pc.explained_variance_ratio_[1]).to_csv(O + "/cl3_pca_loadings_nopdr.csv")
print("done")
