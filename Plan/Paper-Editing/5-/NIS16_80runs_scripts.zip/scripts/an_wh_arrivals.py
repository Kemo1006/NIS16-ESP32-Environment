"""Step 5a. Wormhole: what the root's arrival log shows for the probes of end B (duplicates, spread between the two copies, order of arrival).
Reads the root's *_arrivals.csv of each of the 36 wormhole runs (trimmed/ copy if trim_run made one) and the pooled table (to know which board is B)."""
import glob, os, re
import numpy as np, pandas as pd
from cfg import *

raw = pd.read_pickle(PKL + "/pooled_raw.pkl")
rows = []
for t in TOPOS:
    for l in SITES:
        for s in SCEN:
            cell = f"wormhole/{t}/{l}/{s}"
            g = raw[(raw.cell == cell) & (raw.phase == "attack")]
            B = g[g.node_role == "wormhole_b"].node_id.mode().iloc[0]; A = g[g.node_role == "wormhole_a"].node_id.mode().iloc[0]
            d = f"{R}/datasets/exports/wormhole/{t}/{l}/{s}"
            fs = glob.glob(d + "/trimmed/*_arrivals.csv") or glob.glob(d + "/*_arrivals.csv")
            assert len(fs) == 1, (cell, fs)
            a = pd.read_csv(fs[0])
            a["mac"] = "NODE_" + a.src_mac.str.replace(":", "").str.upper()
            a = a[a.phase_id.isin([0, 1, 2, 3])]                               # the run's own phases (255 = before the run)
            a["phase"] = a.phase_id.map({0: "baseline", 1: "attack", 2: "attack", 3: "cooldown"})
            for who, node in (("B", B), ("A", A), ("children", None)):
                x = a[a.mac == node] if node else a[~a.mac.isin([A, B])]
                for ph in ("baseline", "attack", "cooldown"):
                    y = x[x.phase == ph]
                    if y.empty: continue
                    n_by_seq = y.groupby(["mac", "seq_num"]).size()
                    # copies arrive in the phase of the root's clock at arrival; both copies count to their own arrival phase
                    uniq = len(n_by_seq); dup = int((n_by_seq >= 2).sum())
                    # spread between the two copies of one probe (ms) = |difference of latencies| on the same probe
                    gg = y.groupby(["mac", "seq_num"]).latency_us.agg(["max", "min", "size"]); gg = gg[gg["size"] >= 2]
                    spread_ms = ((gg["max"] - gg["min"]) / 1000.0).values
                    # order: a probe arrives out of order when a probe with a LOWER sequence number reaches the root after a higher one
                    yy = y.sort_values("timestamp_us"); seq = yy.groupby("mac").seq_num.apply(lambda v: int((v.values < np.maximum.accumulate(v.values)).sum())).sum()
                    rows.append(dict(cell=cell, topology=t, location=l, scenario=s, who=who, phase=ph, arrivals=len(y), distinct_probes=uniq,
                                     probes_arriving_twice=dup, share_twice=dup / uniq if uniq else np.nan,
                                     out_of_order_arrivals=int(seq), share_out_of_order=seq / len(y),
                                     spread_ms_median=np.median(spread_ms) if len(spread_ms) else np.nan,
                                     spread_ms_p90=np.percentile(spread_ms, 90) if len(spread_ms) else np.nan,
                                     spread_ms_max=spread_ms.max() if len(spread_ms) else np.nan))
res = pd.DataFrame(rows); res.to_csv(CSV + "/wh_arrivals_per_run.csv", index=False)
pd.set_option("display.width", 250)
print(res.groupby(["who", "phase"])[["arrivals", "probes_arriving_twice", "distinct_probes", "out_of_order_arrivals"]].sum().assign(
    share_twice=lambda d: d.probes_arriving_twice / d.distinct_probes, share_ooo=lambda d: d.out_of_order_arrivals / d.arrivals).round(4))
print(res[(res.who == "B") & (res.phase == "attack")][["cell", "distinct_probes", "probes_arriving_twice", "share_twice", "out_of_order_arrivals", "spread_ms_median", "spread_ms_p90"]].round(3).to_string())
