"""Step 4b. Blackhole extras: run-clock audit, retry counters, collapse and recovery of delivery, dataset summary, feature coverage."""
import numpy as np, pandas as pd
from cfg import *
import leakage
O=CSV
raw=pd.read_pickle(PKL+'/pooled_raw.pkl'); raw=raw[raw.kind=='blackhole'].copy()
raw['cell']=raw.topology+'/'+raw.location+'/'+raw.scenario
u=pd.read_pickle(PKL+'/bh_use.pkl')

# 1. clock-only audit (paper: run-clock position alone scored 0.857 on one early run)
lab=u[(u.node_role!='root')&u.Label.notna()]
a=leakage.single_feature_decidability(lab, candidates=['window_start','t_anchor_s'])
a['population']='all non-root nodes'
v=lab[(lab.node_role=='child')&(lab.exposure=='downstream')]
b=leakage.single_feature_decidability(v, candidates=['window_start','t_anchor_s']); b['population']='victims only'
c=lab[lab.node_role=='child']
d=leakage.single_feature_decidability(c, candidates=['window_start','t_anchor_s']); d['population']='child nodes'
clock=pd.concat([a,d,b]); clock.to_csv(O+'/bh_leakage_audit_run_clock.csv',index=False)
print(clock.round(3).to_string())

# 2. retry counters / rate: did victims' retries move?
ch=u[u.node_role=='child']
rr=ch.groupby(['exposure','segment'])[['RetryRate','retry_count_delta','tx_count_delta','MacRetryRate']].agg(['mean','max']).round(4)
print(rr.to_string())
rr.to_csv(O+'/bh_retry_counters_by_phase.csv')

# 3. collapse and recovery time of victims (per board, own clock)
rows=[]
for (cell,node),g in ch[ch.exposure=='downstream'].groupby(['cell','node_id']):
    g=g.sort_values('window_start')
    att=g[g.segment=='attack']
    if att.empty: continue
    a0=att.window_start.min(); a1=att.window_start.max()
    below=att[(att.PDR<0.5)]
    t_drop=(below.window_start.min()-a0) if len(below) else np.nan
    cd=g[(g.segment=='cooldown')&(g.window_start>a1)]
    up=cd[cd.PDR>=0.5]
    t_rec=(up.window_start.min()-a1) if len(up) else np.nan
    rows.append(dict(cell=cell,topology=cell.split('/')[0],node_id=node,hop=g.hop.mode().iloc[0] if g.hop.notna().any() else np.nan,
                     t_to_PDR_below_0p5_s=t_drop,t_to_PDR_back_above_0p5_s=t_rec,attack_PDR_mean=att.PDR.mean()))
cr=pd.DataFrame(rows); cr.to_csv(O+'/bh_collapse_recovery_per_victim.csv',index=False)
s=cr.groupby('topology')[['t_to_PDR_below_0p5_s','t_to_PDR_back_above_0p5_s']].describe().round(1)
print(cr.groupby('topology')[['t_to_PDR_below_0p5_s','t_to_PDR_back_above_0p5_s']].agg(['median','mean','max','count']).round(1).to_string())
print('all', cr[['t_to_PDR_below_0p5_s','t_to_PDR_back_above_0p5_s']].agg(['median','mean','max','count']).round(1).to_string())
cr.groupby('topology')[['t_to_PDR_below_0p5_s','t_to_PDR_back_above_0p5_s']].agg(['median','mean','max','count']).round(2).to_csv(O+'/bh_collapse_recovery_by_topology.csv')

# 4. dataset summary per cell (windows by phase, boards, coverage)
rows=[]
for cell,g in raw.groupby('cell'):
    r=dict(cell=cell, boards=g.node_id.nunique(), windows_total=len(g))
    for s_ in ['pre_baseline','baseline','attack','cooldown','transition','no_phase_seen']:
        r['windows_'+s_]=int((g.segment==s_).sum())
    r['mean_samples_present_of_10']=g.n_samples_present.mean()
    r['windows_below_8_of_10']=int((g.n_samples_present<8).sum())
    r['boards_missing_labelled_windows']=int(g.node_id.nunique()-g[g.Label.notna()].node_id.nunique())
    rows.append(r)
ds=pd.DataFrame(rows); ds.to_csv(O+'/bh_dataset_summary_per_cell.csv',index=False)
print(ds.describe().round(1).T[['min','mean','max']].to_string())
print(ds[ds.boards_missing_labelled_windows>0][['cell','boards_missing_labelled_windows','windows_no_phase_seen']])
tot=ds[[c for c in ds.columns if c.startswith('windows_')]].sum(); print(tot)

# features with no usable data in the blackhole pooled table
feats=leakage.TABLE_4_11_FEATURES
cov=pd.DataFrame({'feature':feats,'populated_all_rows':[raw[f].notna().mean() for f in feats],
                  'populated_attacker':[raw[raw.node_role=='blackhole'][f].notna().mean() for f in feats],
                  'populated_child':[raw[raw.node_role=='child'][f].notna().mean() for f in feats],
                  'populated_root':[raw[raw.node_role=='root'][f].notna().mean() for f in feats],
                  'distinct_values_non_null':[raw[f].nunique() for f in feats]})
cov.to_csv(O+'/bh_feature_coverage.csv',index=False); print(cov.round(3).to_string())
