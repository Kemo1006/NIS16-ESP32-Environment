"""Step 5b. Wormhole EDA on the 36 wormhole runs: per-run evidence, summaries, Table 3.5 predictions, effect sizes, single-feature audit, figures.
Reads pkl/pooled_raw.pkl, out/csv/verify_summary.csv, verify_checks.csv, wh_arrivals_per_run.csv. Writes out/csv/wh_*.csv, out/fig/wh_*.png, pkl/wh_use.pkl"""
import warnings
import numpy as np, pandas as pd
from scipy import stats
from cfg import *
import leakage
warnings.filterwarnings("ignore")
plt = mpl()
from matplotlib.patches import Patch
O, OF = CSV, FIG
NOTE = f"Wormhole · 36 runs · THESIS3 @ {COMMIT} (24 Oct 2026)"

raw = pd.read_pickle(PKL + "/pooled_raw.pkl")
wh = raw[raw.kind == "wormhole"].copy()
wh["cell"] = wh.topology + "/" + wh.location + "/" + wh.scenario
use = wh[wh.phase.notna()].copy()
use["grp"] = use.node_role.map({"wormhole_a": "A (exit)", "wormhole_b": "B (entry)", "child": "child", "root": "root"})
use.to_pickle(PKL + "/wh_use.pkl")
ver = pd.read_csv(O + "/verify_summary.csv"); ver = ver[ver.kind == "wormhole"].copy()
ver["cell"] = ver.topology + "/" + ver.location + "/" + ver.scenario
arr = pd.read_csv(O + "/wh_arrivals_per_run.csv"); arr["cell"] = arr.topology + "/" + arr.location + "/" + arr.scenario

# ------------------------------------------------------------------ 1. per-run evidence
rows = []
for cell, g in use.groupby("cell"):
    A, B, C = (g[g.node_role == r] for r in ("wormhole_a", "wormhole_b", "child"))
    aa, bb = A[A.phase == "attack"], B[B.phase == "attack"]
    base_b, att_b = B[B.phase == "baseline"], bb
    v = ver[ver.cell == cell].iloc[0]
    ar = arr[(arr.cell == cell) & (arr.who == "B") & (arr.phase == "attack")].iloc[0]
    arc = arr[(arr.cell == cell) & (arr.who == "children") & (arr.phase == "attack")].iloc[0]
    tl = bb.TunnelLatency.dropna()
    ps = g[g.phase.notna()]
    rows.append(dict(
        cell=cell, topology=cell.split("/")[0], site=cell.split("/")[1], scenario=cell.split("/")[2],
        grade=v.grade, topology_check=v.glance_topology, A_hop=aa.hop.median(), B_hop=bb.hop.median(),
        A_hop_constant=bool(aa.hop.nunique() == 1), B_hop_constant=bool(bb.hop.nunique() == 1),
        hops_skipped=bb.hop.median() - aa.hop.median(),
        uart_B_sent=v.uart_B_sent, uart_A_received=v.uart_A_recv, uart_pct=v.uart_pct,
        B_attack_windows=len(bb), B_windows_with_duplicate=int(tl.size), B_duplicate_share=tl.size / len(bb) if len(bb) else np.nan,
        B_baseline_windows_with_duplicate=int(base_b.TunnelLatency.notna().sum()),
        TunnelIntensity_B_attack=bb.TunnelIntensity.mean(), TunnelIntensity_A_attack=aa.TunnelIntensity.mean(),
        TunnelIntensity_B_baseline=base_b.TunnelIntensity.mean(), TunnelBytes_B_attack=bb.TunnelBytes.mean(),
        TunnelLatency_median_ms=tl.median(), TunnelLatency_p90_ms=tl.quantile(.9), TunnelLatency_p99_ms=tl.quantile(.99),
        TunnelLatency_max_ms=tl.max(), TunnelLatency_mean_ms=tl.mean(), windows_over_200ms=int((tl > 200).sum()),
        B_probes_attack=int(ar.distinct_probes), B_probes_arriving_twice=int(ar.probes_arriving_twice), B_share_twice=ar.share_twice,
        B_out_of_order_arrivals=int(ar.out_of_order_arrivals), B_arrivals=int(ar.arrivals),
        children_probes_arriving_twice=int(arc.probes_arriving_twice),
        LHR_B_baseline_median=base_b.LatencyHopRatio.median(), LHR_B_attack_median=bb.LatencyHopRatio.median(),
        child_PDR_baseline=C[C.phase == "baseline"].PDR.mean(), child_PDR_attack=C[C.phase == "attack"].PDR.mean(),
        child_PDR_cooldown=C[C.phase == "cooldown"].PDR.mean(), children=C.node_id.nunique(),
        windows_with_parent_change_all_boards=int((ps.ParentSwitchRate > 0).sum()), windows_with_hop_change_all_boards=int((ps.HopChangeCount > 0).sum()),
        windows_with_parent_change_attack=int((ps[ps.phase == "attack"].ParentSwitchRate > 0).sum()),
        RSSI_Hop_Diff_B_base=base_b.RSSI_Hop_Diff.mean(), RSSI_Hop_Diff_B_att=bb.RSSI_Hop_Diff.mean(),
        RSSI_Hop_Diff_A_base=A[A.phase == "baseline"].RSSI_Hop_Diff.mean(), RSSI_Hop_Diff_A_att=aa.RSSI_Hop_Diff.mean(),
        normal_windows_verifier=v.normal_windows_verifier, attack_windows_verifier=v.attack_windows_verifier,
        capture_start=ps.source_file.dropna().iloc[0] if ps.source_file.notna().any() else ""))
per = pd.DataFrame(rows)
# capture time of the root file (the only file name that carries the start of the run)
import re, glob
def root_stamp(r):
    fs = sorted(glob.glob(f"{R}/datasets/exports/wormhole/{r.topology}/{r.site}/{r.scenario}/root_*_telem.csv"))
    m = re.search(r"_r(\d+)_(\w{3}\d+)_(\d{4})([AP]M)", fs[0]) if fs else None
    return f"{m.group(2)} {m.group(3)[:2]}:{m.group(3)[2:]} {m.group(4)}" if m else ""
per["root_capture"] = per.apply(root_stamp, axis=1)
per = per.drop(columns=["capture_start"])
per.to_csv(O + "/wh_per_run.csv", index=False)
print(per[["cell", "grade", "A_hop", "B_hop", "hops_skipped", "B_duplicate_share", "B_share_twice", "TunnelLatency_median_ms", "TunnelLatency_p90_ms", "windows_with_parent_change_all_boards"]].round(3).to_string())

# ------------------------------------------------------------------ 2. summaries
def summ(g):
    return pd.Series(dict(runs=len(g), confirmed=int((ver.set_index("cell").loc[g.cell, "result"] == "CONFIRMED").sum()),
        hops_min=g.hops_skipped.min(), hops_median=g.hops_skipped.median(), hops_max=g.hops_skipped.max(),
        duplicate_share_min=g.B_duplicate_share.min(), share_twice_min=g.B_share_twice.min(),
        TL_median_of_medians=g.TunnelLatency_median_ms.median(), TL_median_min=g.TunnelLatency_median_ms.min(), TL_median_max=g.TunnelLatency_median_ms.max(),
        TL_p90_median=g.TunnelLatency_p90_ms.median(), uart_min=g.uart_pct.min(), uart_max=g.uart_pct.max()))
by_topo = per.groupby("topology").apply(summ); by_topo.loc["All"] = summ(per)
by_topo.to_csv(O + "/wh_by_topology.csv"); print(by_topo.round(2).to_string())
by_scen = per.groupby("scenario").apply(summ); by_scen.to_csv(O + "/wh_by_scenario.csv"); print(by_scen.round(2).to_string())
sp = stats.spearmanr(per.hops_skipped, per.TunnelLatency_median_ms); sp90 = stats.spearmanr(per.hops_skipped, per.TunnelLatency_p90_ms)
pd.DataFrame([dict(test="Spearman: hops skipped vs median TunnelLatency (36 runs)", rho=sp.statistic, p=sp.pvalue),
              dict(test="Spearman: hops skipped vs p90 TunnelLatency (36 runs)", rho=sp90.statistic, p=sp90.pvalue)]).to_csv(O + "/wh_latency_vs_hops.csv", index=False)
print("hops vs median TL", sp, "\nhops vs p90 TL", sp90)

# ------------------------------------------------------------------ 3. 3-sigma checks of the verifier
chk = pd.read_csv(O + "/verify_checks.csv"); chk = chk[chk.kind == "wormhole"]
c3 = chk.groupby("feature").agg(runs=("cell", "size"), passed=("status", lambda s: (s == "PASS").sum()),
        baseline_sd_zero=("normal_sd", lambda s: (s == 0).sum()), attack_min=("attack_value", "min"), attack_median=("attack_value", "median"), attack_max=("attack_value", "max"),
        normal_max=("normal_mean", "max")).reset_index()
c3.to_csv(O + "/wh_3sigma_summary.csv", index=False); print(c3.to_string())

# ------------------------------------------------------------------ 4. effect sizes by role group
def cohen(b, a):
    if len(b) < 10 or len(a) < 10: return np.nan
    sd = np.sqrt((b.var() + a.var()) / 2)
    return (a.mean() - b.mean()) / sd if sd > 0 else np.nan
feat_eff = ["TunnelIntensity", "TunnelBytes", "TunnelLatency", "RSSI_mean", "RSSI_var", "RSSI_stability", "RSSI_Hop_Diff", "LatencyHopRatio",
            "ParentSwitchRate", "HopChangeCount", "HopStabilityDuration", "IngressEgressDelta", "PDR", "RetryRate"]
er = []
for grp in ("A (exit)", "B (entry)", "child"):
    x = use[use.grp == grp]
    for f in feat_eff:
        b, t, c = (x[x.phase == p][f].dropna() for p in ("baseline", "attack", "cooldown"))
        if len(t) == 0 and len(b) == 0: continue
        er.append(dict(group=grp, feature=f, n_baseline=len(b), n_attack=len(t), baseline_mean=b.mean(), baseline_sd=b.std(), attack_mean=t.mean(), attack_sd=t.std(),
                       cooldown_mean=c.mean(), baseline_median=b.median(), attack_median=t.median(), cohens_d=cohen(b, t),
                       baseline_constant=bool(len(b) > 0 and b.std() == 0)))
eff = pd.DataFrame(er); eff.to_csv(O + "/wh_effect_sizes.csv", index=False)
print(eff.round(4).to_string())

# ------------------------------------------------------------------ 5. Table 3.5 predictions
ends = use[use.node_role.isin(["wormhole_a", "wormhole_b"])]
def share_gt(x, thr=10): x = x.dropna(); return (x.abs() > thr).mean() if len(x) else np.nan
pred = []
hc = use.groupby("phase").agg(parent_change_windows=("ParentSwitchRate", lambda s: int((s > 0).sum())), hop_change_windows=("HopChangeCount", lambda s: int((s > 0).sum())), windows=("hop", "size"))
pred.append(dict(row="Hop count consistency", expected="Nodes report unexpectedly low hop counts given physical placement",
    measured=f"hop of A and B constant during the attack in {int(per.A_hop_constant.sum())} and {int(per.B_hop_constant.sum())} of 36 runs; windows with a hop change (all boards): baseline {hc.loc['baseline','hop_change_windows']}, attack {hc.loc['attack','hop_change_windows']}, cooldown {hc.loc['cooldown','hop_change_windows']}",
    observed="No"))
pred.append(dict(row="Parent-child validity", expected="Relationships violate physical constraints",
    measured=f"windows with a parent change (all boards): baseline {hc.loc['baseline','parent_change_windows']}, attack {hc.loc['attack','parent_change_windows']}, cooldown {hc.loc['cooldown','parent_change_windows']}",
    observed="No"))
pred.append(dict(row="Routing table entries", expected="Self-referential entries or impossible neighbour relationships", measured="The routing table is not logged by the firmware, so it is not measured", observed="Not measured"))
rh = {g: (ends[(ends.grp == g) & (ends.phase == "baseline")].RSSI_Hop_Diff, ends[(ends.grp == g) & (ends.phase == "attack")].RSSI_Hop_Diff) for g in ("A (exit)", "B (entry)")}
pred.append(dict(row="RSSI-hop correlation", expected="High RSSI observed from physically distant nodes",
    measured="RSSI_Hop_Diff mean baseline -> attack: " + "; ".join(f"{g[:1]} {b.mean():.2f} -> {a.mean():.2f} dB (windows above 10 dB: {share_gt(b):.1%} -> {share_gt(a):.1%})" for g, (b, a) in rh.items()), observed="No"))
rv = {g: (ends[(ends.grp == g) & (ends.phase == "baseline")].RSSI_var, ends[(ends.grp == g) & (ends.phase == "attack")].RSSI_var) for g in ("A (exit)", "B (entry)")}
pred.append(dict(row="RSSI variance", expected="Abnormally high RSSI values inconsistent with the expected path loss",
    measured="RSSI_var mean baseline -> attack: " + "; ".join(f"{g[:1]} {b.mean():.3f} -> {a.mean():.3f} dBm^2 (d = {cohen(b.dropna(), a.dropna()):.2f})" for g, (b, a) in rv.items()), observed="No"))
aB = arr[(arr.who == "B")].groupby("phase")[["distinct_probes", "probes_arriving_twice", "arrivals", "out_of_order_arrivals"]].sum()
aC = arr[(arr.who == "children")].groupby("phase")[["distinct_probes", "probes_arriving_twice", "arrivals", "out_of_order_arrivals"]].sum()
pred.append(dict(row="Frame arrival pattern", expected="Duplicates or out-of-order frames due to tunnelling",
    measured=f"probes of B reaching the root twice: baseline {aB.loc['baseline','probes_arriving_twice']} of {aB.loc['baseline','distinct_probes']}, attack {aB.loc['attack','probes_arriving_twice']} of {aB.loc['attack','distinct_probes']} ({aB.loc['attack','probes_arriving_twice']/aB.loc['attack','distinct_probes']:.2%}); out-of-order arrivals of B in the attack {aB.loc['attack','out_of_order_arrivals']} of {aB.loc['attack','arrivals']} ({aB.loc['attack','out_of_order_arrivals']/aB.loc['attack','arrivals']:.2%}); children: {aC['probes_arriving_twice'].sum()} probes twice",
    observed="Yes (duplicates); out-of-order is rare"))
pred.append(dict(row="Retransmission count", expected="May increase near tunnel endpoints due to timing issues",
    measured="RetryRate of B is 0.50 in the attack and 0.00 in the baseline, but on B the retry counter holds the tunnelled frames (D-15, features.py), so it is not a retransmission count; MacRetryRate has no values in the wormhole runs; RetryRate of the children is 0.000 in every phase",
    observed="Not measurable on the ends; none on the children"))
pred.append(dict(row="Duplicate arrivals", expected="The same probe reaches the root twice",
    measured=f"B windows with a duplicate: {int(per.B_windows_with_duplicate.sum())} of {int(per.B_attack_windows.sum())} attack windows ({per.B_windows_with_duplicate.sum()/per.B_attack_windows.sum():.1%}) and {int(per.B_baseline_windows_with_duplicate.sum())} baseline windows",
    observed="Yes"))
tl_all = use[(use.node_role == "wormhole_b") & (use.phase == "attack")].TunnelLatency.dropna()
pred.append(dict(row="Latency mismatch (TunnelLatency)", expected="The two arrivals of one probe differ in latency",
    measured=f"spread between the two copies: median {tl_all.median():.1f} ms, 90th percentile {tl_all.quantile(.9):.1f} ms, 99th percentile {tl_all.quantile(.99):.0f} ms over {len(tl_all):,} windows; Spearman rho with hops skipped (run medians) = {sp.statistic:.2f}",
    observed="Yes"))
pd.DataFrame(pred).to_csv(O + "/wh_predictions_table35.csv", index=False)
for p in pred: print(p["row"], "|", p["measured"], "|", p["observed"])

# ------------------------------------------------------------------ 6. single-feature audit (the repo's own function) + clock audit
lab = use[use.node_role != "root"].copy()
pops = {"child nodes": lab[lab.node_role == "child"], "tunnel ends A and B": lab[lab.node_role.isin(["wormhole_a", "wormhole_b"])], "end B only": lab[lab.node_role == "wormhole_b"]}
aud = []
for name, d in pops.items():
    a_ = leakage.single_feature_decidability(d, candidates=leakage.TABLE_4_11_FEATURES); a_ = add_subset_majority(a_, d); a_["population"] = name; aud.append(a_)
    c_ = leakage.single_feature_decidability(d, candidates=["window_start", "t_anchor_s"]); c_["population"] = name; aud.append(c_)
aud = pd.concat(aud); aud.to_csv(O + "/wh_leakage_audit.csv", index=False)
print(aud.round(3).to_string())

# ------------------------------------------------------------------ figures
# Fig 1: grid of the hops skipped and the median spread
fig, axes = plt.subplots(1, 4, figsize=(11.5, 4.1), sharey=True)
for ax, topo in zip(axes, TOPOS):
    M = np.full((3, 3), np.nan); T = {}
    for i, s_ in enumerate(SITES):
        for j, sc in enumerate(SCEN):
            r = per[(per.topology == topo) & (per.site == s_) & (per.scenario == sc)].iloc[0]
            M[i, j] = r.hops_skipped; T[(i, j)] = f"{int(r.hops_skipped)} hop{'s' if r.hops_skipped > 1 else ''}\n{r.TunnelLatency_median_ms:.1f} ms"
    im = ax.imshow(M, vmin=0, vmax=5, cmap="Purples", aspect="auto")
    for (i, j), tx in T.items(): ax.text(j, i, tx, ha="center", va="center", fontsize=7.5, color="white" if M[i, j] >= 4 else "black")
    ax.set_title(topo.replace("_", " ")); ax.set_xticks(range(3)); ax.set_xticklabels(SCEN, rotation=30); ax.set_yticks(range(3)); ax.set_yticklabels(SITES)
fig.colorbar(im, ax=axes, shrink=.8, label="hops skipped by the tunnel (hop of B minus hop of A)")
fig.suptitle("Hops skipped by the tunnel, and median spread between the two copies of a probe, in every wormhole run", fontweight="bold", y=1.02)
fig.text(0.01, -0.03, NOTE, fontsize=7, color=C_GREY); fig.savefig(OF + "/wh_fig1_cell_grid_hops_latency.png", bbox_inches="tight"); plt.close(fig)

# Fig 2: tunnel activity over the run (B), by scenario
B_ = use[(use.node_role == "wormhole_b")]
A_ = use[(use.node_role == "wormhole_a")]
fig, axes = plt.subplots(1, 3, figsize=(12.5, 3.6), sharex=True)
cols = {"stationary": "#2b6cb0", "burst": "#dd6b20", "highload": "#2f855a"}
for sc, col in cols.items():
    s_ = B_[(B_.scenario == sc) & (B_.t_rel >= -120) & (B_.t_rel <= 300)]
    g = s_.groupby("t_rel").TunnelIntensity.mean().rolling(3, center=True, min_periods=1).mean()
    axes[0].plot(g.index, g, color=col, label=sc, lw=1.5)
    d = s_.groupby("t_rel").TunnelLatency.apply(lambda v: v.notna().mean()).rolling(3, center=True, min_periods=1).mean()
    axes[1].plot(d.index, d, color=col, label=sc, lw=1.5)
    m = s_.groupby("t_rel").TunnelLatency.median().rolling(5, center=True, min_periods=1).median()
    axes[2].plot(m.index, m, color=col, label=sc, lw=1.2)
for ax in axes: ax.axvspan(0, 180, color=C_ATT, alpha=.06); ax.set_xlabel("seconds from the attack start (per board)")
axes[0].set_ylabel("TunnelIntensity of B (messages/s)"); axes[1].set_ylabel("share of B windows with a duplicate at the root"); axes[2].set_ylabel("TunnelLatency (ms), median over runs")
axes[0].set_title("Tunnel traffic follows the probe rate"); axes[1].set_title("Duplicates exist only in the attack"); axes[2].set_title("Spread between the two copies")
axes[0].legend(frameon=False, fontsize=8)
fig.text(0.01, -0.03, NOTE + " · mean over runs (12 per scenario)", fontsize=7, color=C_GREY)
fig.tight_layout(); fig.savefig(OF + "/wh_fig2_tunnel_over_run.png", bbox_inches="tight"); plt.close(fig)

# Fig 3: TunnelLatency distribution by topology, and against the hops skipped
tl = use[(use.node_role == "wormhole_b") & (use.phase == "attack")].dropna(subset=["TunnelLatency"])
fig, axes = plt.subplots(1, 2, figsize=(11.5, 4))
data = [tl[tl.topology == t_].TunnelLatency.values for t_ in TOPOS]
bp = axes[0].boxplot(data, tick_labels=[t_.replace("_", " ") for t_ in TOPOS], showfliers=True, patch_artist=True, flierprops=dict(marker=".", ms=2, alpha=.4), whis=(5, 95))
for p_ in bp["boxes"]: p_.set_facecolor(C_WH); p_.set_alpha(.55)
axes[0].set_yscale("log"); axes[0].set_ylabel("TunnelLatency (ms, log scale)"); axes[0].set_title("Spread between the two copies, by topology")
axes[0].set_ylim(top=1e5)
for i, d in enumerate(data): axes[0].text(i + 1, 0.95, f"n = {len(d):,}", ha="center", va="top", fontsize=7, transform=axes[0].get_xaxis_transform())
mk = {"stationary": "o", "burst": "s", "highload": "^"}
for sc, m_ in mk.items():
    x = per[per.scenario == sc]
    axes[1].scatter(x.hops_skipped + np.random.default_rng(1).uniform(-.12, .12, len(x)), x.TunnelLatency_median_ms, marker=m_, s=34, color=C_WH, alpha=.7, label=sc)
axes[1].set_xlabel("hops skipped by the tunnel"); axes[1].set_ylabel("median TunnelLatency of the run (ms)")
axes[1].set_title(f"Median spread against hops skipped (Spearman rho = {sp.statistic:.2f}, 36 runs)"); axes[1].legend(frameon=False, fontsize=8)
fig.text(0.01, -0.02, NOTE + " · boxes: IQR, whiskers 5th–95th percentile", fontsize=7, color=C_GREY)
fig.tight_layout(); fig.savefig(OF + "/wh_fig3_tunnel_latency.png", bbox_inches="tight"); plt.close(fig)

# Fig 4: children's PDR in the wormhole runs (nothing happens to them), against the blackhole victims
bh = pd.read_pickle(PKL + "/bh_use.pkl")
fig, axes = plt.subplots(1, 4, figsize=(13, 3.2), sharey=True)
for ax, topo in zip(axes, TOPOS):
    s_ = use[(use.topology == topo) & (use.node_role == "child")].dropna(subset=["PDR"]); s_ = s_[(s_.t_rel >= -180) & (s_.t_rel <= 300)]
    g = s_.groupby("t_rel").PDR.mean().rolling(5, center=True, min_periods=1).mean()
    ax.plot(g.index, g, color=C_WH, lw=1.6, label="wormhole: all non-attacker nodes")
    v_ = bh[(bh.topology == topo) & (bh.node_role == "child") & (bh.exposure == "downstream")].dropna(subset=["PDR"]); v_ = v_[(v_.t_rel >= -180) & (v_.t_rel <= 300)]
    g2 = v_.groupby("t_rel").PDR.mean().rolling(5, center=True, min_periods=1).mean()
    ax.plot(g2.index, g2, color=C_BH, lw=1.3, ls="--", label="blackhole: victims")
    ax.axvspan(0, 180, color=C_ATT, alpha=.06); ax.set_title(topo.replace("_", " ")); ax.set_ylim(-.05, 1.08); ax.set_xlabel("seconds from attack start")
axes[0].set_ylabel("PDR (5 s smoothed)"); hh, ll = axes[0].get_legend_handles_labels(); fig.legend(hh, ll, loc="lower center", ncol=2, frameon=False, fontsize=8, bbox_to_anchor=(.5, -.12))
fig.suptitle("A wormhole leaves the delivery of every node untouched; a blackhole removes it", fontweight="bold", y=1.03)
fig.text(0.01, -0.12, NOTE, fontsize=7, color=C_GREY); fig.tight_layout(); fig.savefig(OF + "/wh_fig4_pdr_wormhole_vs_blackhole.png", bbox_inches="tight"); plt.close(fig)

# Fig 5: distributions by phase for the ends and the children
feat_show = ["TunnelIntensity", "TunnelBytes", "TunnelLatency", "LatencyHopRatio", "RSSI_mean", "RSSI_var", "RSSI_Hop_Diff", "HopStabilityDuration", "IngressEgressDelta", "PDR"]
fig, axes = plt.subplots(2, 5, figsize=(14, 5.6))
for ax, f in zip(axes.flat, feat_show):
    data, labels, colors = [], [], []
    for grp, tag in (("child", "children"), ("A (exit)", "A"), ("B (entry)", "B")):
        for ph, col in (("baseline", C_BASE), ("attack", C_ATT)):
            x = use[(use.grp == grp) & (use.phase == ph)][f].dropna()
            if f in ("LatencyHopRatio", "TunnelLatency"): x = np.log10(x + 1)
            if len(x) > 20000: x = x.sample(20000, random_state=1)
            if len(x) == 0: x = pd.Series([np.nan])
            data.append(x.values); labels.append(f"{tag}\n{ph}"); colors.append(col)
    bp = ax.boxplot(data, tick_labels=labels, patch_artist=True, showfliers=False, widths=.6)
    for patch, c in zip(bp["boxes"], colors): patch.set_facecolor(c); patch.set_alpha(.7)
    for m in bp["medians"]: m.set_color("black")
    ax.set_title(("log10(1+" + f + ")") if f in ("LatencyHopRatio", "TunnelLatency") else f, fontsize=8.5); ax.tick_params(axis="x", labelsize=6)
fig.suptitle("Wormhole runs: feature distributions by phase for the children, end A and end B (boxes: IQR, whiskers 1.5 IQR)", fontweight="bold")
fig.text(0.01, -0.01, NOTE, fontsize=7, color=C_GREY); fig.tight_layout(); fig.savefig(OF + "/wh_fig5_feature_distributions.png", bbox_inches="tight"); plt.close(fig)

# Fig 6: single-feature audit
fig, axes = plt.subplots(1, 3, figsize=(13.5, 4.6), sharex=True)
for ax, (name, d) in zip(axes, pops.items()):
    a_ = aud[(aud.population == name) & aud.feature.isin(leakage.TABLE_4_11_FEATURES)].dropna(subset=["threshold_accuracy"])
    a_ = a_[a_.coverage > .05].sort_values("threshold_accuracy")
    cols_ = [C_ATT if v > .9 else C_GREY if e else C_BASE for e, v in zip(a_.excluded, a_.threshold_accuracy)]
    bars_ = ax.barh(a_.feature, a_.threshold_accuracy, color=cols_)
    for b_, cv_, mc_ in zip(bars_, a_.coverage, a_.majority_among_covered):
        if cv_ < .95: ax.text(max(b_.get_width(), .4) + .008, b_.get_y() + b_.get_height() / 2, f"value in {cv_:.0%} of windows; majority there {mc_:.0%}", va="center", fontsize=6.3, color="#333")
    for b_, e in zip(bars_, a_.excluded):
        if e: b_.set_hatch("///"); b_.set_edgecolor("white")
    ax.axvline(a_.majority_baseline.iloc[0], color="#333", ls="--", lw=1); ax.set_title(name); ax.set_xlim(.4, 1.12); ax.tick_params(axis="y", labelsize=7.5); ax.set_xlabel("best single-threshold accuracy")
fig.legend(handles=[Patch(color=C_ATT, label="decides the label alone (>0.90)"), Patch(color=C_BASE, label="analysed feature"), Patch(color=C_GREY, label="excluded, below 0.90"), Patch(facecolor="white", edgecolor="#555", hatch="///", label="hatched: excluded from model inputs by leakage.py")], loc="lower center", ncol=4, frameon=False, fontsize=8, bbox_to_anchor=(.5, -.06))
fig.suptitle("Wormhole runs: best single-threshold accuracy of each feature (baseline and cooldown = 0, attack = 1)", fontweight="bold")
fig.text(0.01, -0.1, NOTE, fontsize=7, color=C_GREY); fig.tight_layout(); fig.savefig(OF + "/wh_fig6_single_feature_audit.png", bbox_inches="tight"); plt.close(fig)
print("wormhole EDA done")
