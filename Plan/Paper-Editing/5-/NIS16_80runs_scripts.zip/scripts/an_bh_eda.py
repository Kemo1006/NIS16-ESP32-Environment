"""Step 4a. Blackhole EDA on the 36 blackhole runs (latest data). Adapted from the 20 Oct bh_eda.py: same methods, new inputs.
Reads pkl/pooled_raw.pkl and out/csv/verify_summary.csv; writes out/csv/bh_*.csv, out/fig/bh_*.png, pkl/bh_use.pkl"""
import os, sys, warnings
import numpy as np, pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch

warnings.filterwarnings("ignore")
from cfg import *
import leakage  # repo's own audit
O = CSV; OF = FIG

C_BASE, C_ATT, C_COOL, C_GREY = "#2b6cb0", "#c53030", "#718096", "#a0aec0"
plt.rcParams.update({"figure.dpi": 130, "savefig.dpi": 160, "font.size": 9,
                     "axes.spines.top": False, "axes.spines.right": False,
                     "axes.titlesize": 10, "axes.titleweight": "bold"})
NOTE = f"Blackhole · 36 runs · THESIS3 @ {COMMIT} (24 Oct 2026)"

df = pd.read_pickle(PKL + "/pooled_raw.pkl")
df = df[df.kind == "blackhole"].copy()
df["cell"] = df.topology + "/" + df.location + "/" + df.scenario      # short cell name, as in the 20 Oct scripts
REDO = set()
df["redo"] = False
use = df[df.segment.isin(["baseline", "attack", "cooldown"])].copy()      # drop pre_baseline / transition / no_phase_seen
use["phase"] = use.segment
ch = use[use.node_role == "child"].copy()
vic = ch[ch.exposure == "downstream"]
byst = ch[ch.exposure == "upstream"]
att = use[use.node_role == "blackhole"]

print("windows used:", len(use), "| child", len(ch), "| victims", len(vic), "| bystanders", len(byst), "| attacker", len(att))

# ---------------------------------------------------------------- 1. per-cell effect table
rows = []
for cell, g in use.groupby("cell"):
    a = g[g.node_role == "blackhole"]
    c = g[g.node_role == "child"]
    v, b = c[c.exposure == "downstream"], c[c.exposure == "upstream"]
    rows.append(dict(
        cell=cell,
        topology=cell.split("/")[0], site=cell.split("/")[1], scenario=cell.split("/")[2],
        redo_flag=cell in REDO,
        attack_windows=int((g.segment == "attack").sum() / 8),
        attacker_FR_base=a.loc[a.segment == "baseline", "ForwardingRatio"].mean(),
        attacker_FR_attack=a.loc[a.segment == "attack", "ForwardingRatio"].mean(),
        n_victim_nodes=v.node_id.nunique(), n_bystander_nodes=b.node_id.nunique(),
        victim_PDR_base=v.loc[v.segment == "baseline", "PDR"].mean(),
        victim_PDR_attack=v.loc[v.segment == "attack", "PDR"].mean(),
        victim_PDR_cooldown=v.loc[v.segment == "cooldown", "PDR"].mean(),
        bystander_PDR_attack=b.loc[b.segment == "attack", "PDR"].mean(),
    ))
cells = pd.DataFrame(rows)
ver = pd.read_csv(O + "/verify_summary.csv")
ver = ver[ver.kind == "blackhole"].copy()
ver["cell"] = ver.topology + "/" + ver.location + "/" + ver.scenario
cells = cells.merge(ver[["cell", "result", "grade", "setup_FAIL", "setup_WARN", "victims_verifier", "worst_victim_pdr"]], on="cell", how="left")
cells["result"] = cells["result"].str.replace(" - SETUP INVALID", " (SETUP INVALID)")
cells.to_csv(O + "/bh_per_cell_summary.csv", index=False)
print(cells[["cell", "attacker_FR_attack", "victim_PDR_base", "victim_PDR_attack", "bystander_PDR_attack", "result"]].round(3).to_string())

# ---------------------------------------------------------------- Fig 1: cell grid (victim PDR during attack)
fig, axes = plt.subplots(1, 4, figsize=(11, 4.3), sharey=True)
sites = ["G402", "DLSU_Library", "Yuchengco"]
scs = ["stationary", "burst", "highload"]
im = None
for ax, topo in zip(axes, ["linear", "partial_mesh", "star", "tree"]):
    M = np.full((3, 3), np.nan)
    for i, s in enumerate(sites):
        for j, sc in enumerate(scs):
            r = cells[(cells.topology == topo) & (cells.site == s) & (cells.scenario == sc)].iloc[0]
            M[i, j] = r.victim_PDR_attack
    im = ax.imshow(M, vmin=0, vmax=1, cmap="RdYlGn", aspect="auto")
    for i, s in enumerate(sites):
        for j, sc in enumerate(scs):
            r = cells[(cells.topology == topo) & (cells.site == s) & (cells.scenario == sc)].iloc[0]
            txt = f"{r.victim_PDR_attack:.2f}"
            if r.redo_flag:
                txt += "\nREDO"
                ax.add_patch(plt.Rectangle((j - .5, i - .5), 1, 1, fill=False, hatch="///", edgecolor="#333", lw=0))
            ax.text(j, i, txt, ha="center", va="center", fontsize=8, color="black")
    ax.set_title(topo.replace("_", " "))
    ax.set_xticks(range(3)); ax.set_xticklabels(scs, rotation=30)
    ax.set_yticks(range(3)); ax.set_yticklabels(sites)
fig.colorbar(im, ax=axes, shrink=.8, label="mean PDR of nodes behind the attacker, attack phase")
fig.suptitle("Delivery collapses behind the blackhole in every cell", fontweight="bold", y=1.02)
fig.text(0.01, -0.03, NOTE, fontsize=7, color=C_GREY)
fig.savefig(OF + "/bh_fig1_cell_grid_victim_pdr.png", bbox_inches="tight"); plt.close(fig)

# ---------------------------------------------------------------- Fig 2: aligned time series
def attack_start(g):
    return g.loc[g.segment == "attack", "window_start"].min()

# Each board's window_start runs on its OWN clock (boards boot a few seconds apart, up to ~40 s), so the
# phase boundary has to be found per board, not per cell, or the step in PDR smears out over ~40 s.
# a0 and t_rel (seconds from the first attack window of the same board) were added by an_pool.py

ch = use[use.node_role == "child"]
fig, axes = plt.subplots(2, 2, figsize=(11, 6.4), sharex=True)
for ax, topo in zip(axes.flat, ["linear", "partial_mesh", "star", "tree"]):
    sub = ch[(ch.topology == topo)]
    for expo, col, lab in (("downstream", C_ATT, "victims (behind the attacker)"), ("upstream", C_BASE, "bystanders (not behind the attacker)")):
        s = sub[sub.exposure == expo].dropna(subset=["PDR"])
        s = s[(s.t_rel >= -180) & (s.t_rel <= 300)]
        if s.empty:
            continue
        g = s.groupby("t_rel").PDR.agg(["mean", "count"])
        # rolling 5 s so the curve is readable (paper aggregation block = 5 windows)
        m = g["mean"].rolling(5, center=True, min_periods=1).mean()
        q = s.groupby("t_rel").PDR.quantile([.1, .9]).unstack()
        q.columns = ["lo", "hi"]
        q = q.rolling(5, center=True, min_periods=1).mean()
        ax.plot(m.index, m, color=col, label=lab, lw=1.6)
        ax.fill_between(q.index, q["lo"], q["hi"], color=col, alpha=.12, lw=0)
    ax.axvspan(0, 180, color=C_ATT, alpha=.06)
    ax.axvline(0, color="#333", lw=.8, ls="--"); ax.axvline(180, color="#333", lw=.8, ls="--")
    ax.set_title(topo.replace("_", " ")); ax.set_ylim(-.05, 1.08)
    ax.set_ylabel("PDR (5 s smoothed)")
for ax in axes[1]: ax.set_xlabel("seconds from attack start")
hh, ll = axes[0, 0].get_legend_handles_labels()
fig.legend(hh, ll, loc="lower center", ncol=2, fontsize=8.5, frameon=False, bbox_to_anchor=(.5, -.045))
fig.suptitle("Blackhole runs: PDR over the run, pooled across sites and scenarios (line = mean, band = 10th to 90th percentile)", fontweight="bold", y=0.995)
fig.text(0.01, -0.075, NOTE, fontsize=7, color=C_GREY)
fig.tight_layout(); fig.savefig(OF + "/bh_fig2_pdr_timeseries_by_topology.png", bbox_inches="tight"); plt.close(fig)

# ---------------------------------------------------------------- Fig 3: attacker forwarding ratio + neighbour view
a = use[use.node_role == "blackhole"].dropna(subset=["ForwardingRatio"])
fig, axes = plt.subplots(1, 2, figsize=(11, 3.6))
for topo, col in zip(["linear", "partial_mesh", "star", "tree"], ["#2b6cb0", "#805ad5", "#dd6b20", "#2f855a"]):
    s = a[(a.topology == topo) & (a.t_rel >= -180) & (a.t_rel <= 300)]
    g = s.groupby("t_rel").ForwardingRatio.mean().rolling(5, center=True, min_periods=1).mean()
    axes[0].plot(g.index, g, label=topo.replace("_", " "), color=col, lw=1.5)
axes[0].axvspan(0, 180, color=C_ATT, alpha=.06)
axes[0].set_ylim(-.05, 1.3); axes[0].set_xlabel("seconds from attack start"); axes[0].set_ylabel("ForwardingRatio (attacker)")
axes[0].set_title("Attacker forwards ~100% before, ~0% during"); axes[0].legend(frameon=False, fontsize=8, ncol=2)
bins = np.linspace(0, 1.5, 31)
axes[1].hist(a[a.segment == "baseline"].ForwardingRatio.clip(0, 1.5), bins=bins, color=C_BASE, alpha=.8, label="baseline", density=True)
axes[1].hist(a[a.segment == "attack"].ForwardingRatio.clip(0, 1.5), bins=bins, color=C_ATT, alpha=.8, label="attack", density=True)
axes[1].set_xlabel("ForwardingRatio per 1 s window (attacker)"); axes[1].set_ylabel("density"); axes[1].legend(frameon=False)
axes[1].set_title("No overlap between the two phases")
fig.text(0.01, -0.03, NOTE, fontsize=7, color=C_GREY)
fig.tight_layout(); fig.savefig(OF + "/bh_fig3_attacker_forwarding_ratio.png", bbox_inches="tight"); plt.close(fig)

# ---------------------------------------------------------------- Fig 4: distributions by phase, victims vs bystanders
feat_show = ["PDR", "IngressEgressDelta", "RSSI_mean", "RSSI_var", "RSSI_stability", "RSSI_Hop_Diff",
             "ParentSwitchRate", "HopChangeCount", "HopStabilityDuration", "LatencyHopRatio"]
fig, axes = plt.subplots(2, 5, figsize=(13, 5.2))
for ax, f in zip(axes.flat, feat_show):
    data, labels, colors = [], [], []
    for expo, tag in (("upstream", "bystander"), ("downstream", "victim")):
        for ph, col in (("baseline", C_BASE), ("attack", C_ATT)):
            x = ch[(ch.exposure == expo) & (ch.segment == ph)][f].dropna()
            if f == "LatencyHopRatio": x = np.log10(x + 1)
            if len(x) > 20000: x = x.sample(20000, random_state=1)
            data.append(x.values); labels.append(f"{tag}\n{ph}"); colors.append(col)
    bp = ax.boxplot(data, tick_labels=labels, patch_artist=True, showfliers=False, widths=.6)
    for patch, c in zip(bp["boxes"], colors): patch.set_facecolor(c); patch.set_alpha(.7)
    for m in bp["medians"]: m.set_color("black")
    ax.set_title(("log10 " if f == "LatencyHopRatio" else "") + f, fontsize=9)
    ax.tick_params(axis="x", labelsize=6.5)
    if f == "RSSI_stability":
        ax.set_ylim(0.8, 1.0); ax.ticklabel_format(axis="y", useOffset=False)
    q_ = [np.percentile(d_, [25, 50, 75]) if len(d_) else [np.nan] * 3 for d_ in data]
    if all(len(d_) for d_ in data) and all(abs(a_[2] - a_[0]) < 1e-9 for a_ in q_) and len({round(a_[1], 6) for a_ in q_}) == 1:
        ax.text(.5, .93, "one value in every box", transform=ax.transAxes, ha="center", fontsize=7, color=C_GREY)
fig.suptitle("Blackhole runs: feature distributions by phase for the bystanders and the victims (boxes: IQR, whiskers 1.5 IQR)", fontweight="bold")
fig.text(0.01, -0.01, NOTE, fontsize=7, color=C_GREY)
fig.tight_layout(); fig.savefig(OF + "/bh_fig4_feature_distributions.png", bbox_inches="tight"); plt.close(fig)

# descriptive stats by phase x exposure
feats16 = leakage.TABLE_4_11_FEATURES
rows = []
for (expo, ph), g in ch.groupby(["exposure", "segment"]):
    for f in feats16:
        x = g[f].dropna()
        if len(x): rows.append(dict(exposure=expo, phase=ph, feature=f, n=len(x), mean=x.mean(), sd=x.std(), median=x.median(), p05=x.quantile(.05), p95=x.quantile(.95)))
pd.DataFrame(rows).to_csv(O + "/bh_descriptive_by_phase_exposure.csv", index=False)

# ---------------------------------------------------------------- Fig 5: correlations
allowed, excluded = leakage.split_columns(use)
cf = [f for f in allowed if f in ch.columns and ch[f].notna().mean() > .3]
def corr_pair(d, title, ax_p, ax_s):
    x = d[cf].dropna(thresh=int(len(cf) * .7))
    if len(x) > 40000: x = x.sample(40000, random_state=1)
    for ax, how in ((ax_p, "pearson"), (ax_s, "spearman")):
        c = x.corr(method=how)
        ax.imshow(c, vmin=-1, vmax=1, cmap="RdBu_r")
        ax.set_xticks(range(len(cf))); ax.set_xticklabels(cf, rotation=90, fontsize=6.5)
        ax.set_yticks(range(len(cf))); ax.set_yticklabels(cf, fontsize=6.5)
        for i in range(len(cf)):
            for j in range(len(cf)):
                v = c.iloc[i, j]
                if np.isfinite(v) and i != j and abs(v) >= .5:
                    ax.text(j, i, f"{v:.1f}", ha="center", va="center", fontsize=5.5, color="white" if abs(v) > .75 else "black")
        ax.set_title(f"{title} · {how} (n={len(x):,})", fontsize=8.5)
    return x.corr(method="spearman")
fig, axes = plt.subplots(3, 2, figsize=(10, 14))
sp_all = corr_pair(ch, "all child windows", axes[0, 0], axes[0, 1])
sp_b = corr_pair(ch[ch.segment == "baseline"], "baseline only", axes[1, 0], axes[1, 1])
sp_a = corr_pair(ch[ch.segment == "attack"], "attack only", axes[2, 0], axes[2, 1])
fig.suptitle("Feature correlations (child nodes; leakage-guard allowlist)", fontweight="bold", y=0.995)
fig.text(0.01, 0.0, NOTE, fontsize=7, color=C_GREY)
fig.tight_layout(); fig.savefig(OF + "/bh_fig5_correlations.png", bbox_inches="tight"); plt.close(fig)
sp_b.to_csv(O + "/bh_spearman_baseline.csv"); sp_a.to_csv(O + "/bh_spearman_attack.csv"); sp_all.to_csv(O + "/bh_spearman_all.csv")
(sp_a - sp_b).to_csv(O + "/bh_spearman_attack_minus_baseline.csv")

# ---------------------------------------------------------------- Leakage audit (repo's own function)
lab = use[use.node_role != "root"].copy()
audit_all = leakage.single_feature_decidability(lab, candidates=leakage.TABLE_4_11_FEATURES)
audit_ch = leakage.single_feature_decidability(ch, candidates=leakage.TABLE_4_11_FEATURES)
audit_vic = leakage.single_feature_decidability(ch[ch.exposure == "downstream"], candidates=leakage.TABLE_4_11_FEATURES)
audit_all = add_subset_majority(audit_all, lab); audit_ch = add_subset_majority(audit_ch, ch); audit_vic = add_subset_majority(audit_vic, ch[ch.exposure == "downstream"])
audit_all["population"] = "all non-root nodes"; audit_ch["population"] = "child nodes"; audit_vic["population"] = "victims only"
aud = pd.concat([audit_all, audit_ch, audit_vic]); aud.to_csv(O + "/bh_leakage_audit.csv", index=False)
print(aud.round(3).to_string())

fig, axes = plt.subplots(1, 3, figsize=(13, 4.6), sharex=True)
for ax, a_, ttl in zip(axes, (audit_all, audit_ch, audit_vic), ("all non-root nodes", "child nodes", "victims only")):
    a_ = a_.dropna(subset=["threshold_accuracy"])
    a_ = a_[a_.coverage > .05].sort_values("threshold_accuracy")      # drops TunnelLatency (0.2 % coverage = stray values)
    cols = [C_GREY if e else C_ATT if v > .9 else C_BASE for e, v in zip(a_.excluded, a_.threshold_accuracy)]
    bars_ = ax.barh(a_.feature, a_.threshold_accuracy, color=cols)
    for b_, cv_, mc_ in zip(bars_, a_.coverage, a_.majority_among_covered):
        if cv_ < .95: ax.text(max(b_.get_width(), .4) + .008, b_.get_y() + b_.get_height() / 2, f"value in {cv_:.0%} of windows; majority there {mc_:.0%}", va="center", fontsize=6.3, color="#333")
    ax.axvline(a_.majority_baseline.iloc[0], color="#333", ls="--", lw=1)
    ax.text(a_.majority_baseline.iloc[0], -0.9, " majority", fontsize=7, va="top")
    ax.set_title(ttl); ax.set_xlim(.4, 1.12); ax.tick_params(axis="y", labelsize=7.5)
    ax.set_xlabel("best single-threshold accuracy")
fig.legend(handles=[Patch(color=C_ATT, label="allowed feature that decides the label alone (>0.90)"),
                    Patch(color=C_BASE, label="allowed feature"), Patch(color=C_GREY, label="excluded by leakage.py")],
           loc="lower center", ncol=3, frameon=False, fontsize=8, bbox_to_anchor=(.5, -.06))
fig.suptitle("Single-feature leakage audit (analysis/leakage.py): baseline+cooldown = 0 vs attack = 1", fontweight="bold")
fig.text(0.01, -0.1, NOTE, fontsize=7, color=C_GREY)
fig.tight_layout(); fig.savefig(OF + "/bh_fig6_leakage_audit.png", bbox_inches="tight"); plt.close(fig)

# ---------------------------------------------------------------- RSSI / topology: does anything besides delivery move?
rows = []
for f in ["RSSI_mean", "RSSI_var", "RSSI_stability", "RSSI_Hop_Diff", "ParentSwitchRate", "HopChangeCount", "HopStabilityDuration", "IngressEgressDelta", "PDR"]:
    for expo in ("downstream", "upstream"):
        b = ch[(ch.exposure == expo) & (ch.segment == "baseline")][f].dropna()
        t = ch[(ch.exposure == expo) & (ch.segment == "attack")][f].dropna()
        if len(b) > 10 and len(t) > 10:
            pooled_sd = np.sqrt((b.var() + t.var()) / 2)
            rows.append(dict(feature=f, nodes=expo, baseline_mean=b.mean(), attack_mean=t.mean(),
                             cohens_d=(t.mean() - b.mean()) / pooled_sd if pooled_sd > 0 else np.nan))
eff = pd.DataFrame(rows); eff.to_csv(O + "/bh_effect_sizes_baseline_vs_attack.csv", index=False)
print(eff.round(3).to_string())

use.to_pickle(PKL + "/bh_use.pkl")
print("EDA done")
