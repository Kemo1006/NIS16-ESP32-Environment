"""A few facts quoted in Chapter 6 that are not in the other result files: missing-value shares of LatencyHopRatio, retry counters, label shares.
Reads pkl/pooled_raw.pkl.  Writes out/csv/facts_*.csv"""
import numpy as np, pandas as pd
from cfg import *
raw = pd.read_pickle(PKL + "/pooled_raw.pkl")
k = raw[raw.phase.notna()]
rows = []
bh = k[(k.kind == "blackhole") & (k.node_role == "child")]
for expo in ("downstream", "upstream"):
    for ph in ("baseline", "attack", "cooldown"):
        g = bh[(bh.exposure == expo) & (bh.phase == ph)]
        rows.append(dict(group=f"blackhole {expo}", phase=ph, windows=len(g), LHR_undefined_share=g.LatencyHopRatio.isna().mean(), PDR_undefined_share=g.PDR.isna().mean(), PDR_mean=g.PDR.mean()))
wh = k[(k.kind == "wormhole")]
for role in ("child", "wormhole_a", "wormhole_b"):
    for ph in ("baseline", "attack", "cooldown"):
        g = wh[(wh.node_role == role) & (wh.phase == ph)]
        rows.append(dict(group=f"wormhole {role}", phase=ph, windows=len(g), LHR_undefined_share=g.LatencyHopRatio.isna().mean(), PDR_undefined_share=g.PDR.isna().mean(), PDR_mean=g.PDR.mean()))
for ph in ("baseline", "cooldown"):
    g = k[(k.kind == "benign") & (k.node_role == "child") & (k.phase == ph)]
    rows.append(dict(group="benign child", phase=ph, windows=len(g), LHR_undefined_share=g.LatencyHopRatio.isna().mean(), PDR_undefined_share=g.PDR.isna().mean(), PDR_mean=g.PDR.mean()))
pd.DataFrame(rows).to_csv(CSV + "/facts_missing.csv", index=False)
print(pd.DataFrame(rows).round(4).to_string())
# label shares in the pooled analysis (non-attacker boards with a phase label)
ch = k[(k.node_role == "child") & k.Label.notna()]
print(ch.groupby("kind").Label.value_counts().unstack(fill_value=0))
# windows above 10 dB RSSI_Hop_Diff on the tunnel ends
for role in ("wormhole_a", "wormhole_b", "child"):
    for ph in ("baseline", "attack"):
        g = wh[(wh.node_role == role) & (wh.phase == ph)].RSSI_Hop_Diff.dropna()
        print(role, ph, round((g > 10).mean() * 100, 1), len(g))
# RetryRate of B
b = wh[(wh.node_role == "wormhole_b")]
print(b.groupby("phase").RetryRate.agg(["mean", "max", "count"]))
print("MacRetryRate values in the wormhole runs:", int(wh.MacRetryRate.notna().sum()), "| blackhole:", int(k[k.kind=='blackhole'].MacRetryRate.notna().sum()))

# TunnelLatency of the entry end in the attack windows (6,468 values), for the quantiles quoted in Section 6.2.2
tl = wh[(wh.node_role == "wormhole_b") & (wh.phase == "attack")][["cell", "TunnelLatency"]].dropna()
tl.to_csv(CSV + "/wh_tunnel_latency_attack.csv", index=False)
print("TunnelLatency values:", len(tl), tl.TunnelLatency.median(), tl.TunnelLatency.quantile(.9), tl.TunnelLatency.quantile(.99))

# windows with a failed send (RetryRate above 0) by exposure and phase, blackhole non-attacker boards
rows = []
for expo in ("downstream", "upstream"):
    for ph in ("baseline", "attack", "cooldown"):
        g = bh[(bh.exposure == expo) & (bh.phase == ph)]
        rows.append(dict(exposure=expo, phase=ph, windows=len(g), windows_with_value=int(g.RetryRate.notna().sum()), windows_above_zero=int((g.RetryRate > 0).sum()), mean=g.RetryRate.mean(), max=g.RetryRate.max()))
pd.DataFrame(rows).to_csv(CSV + "/bh_retry_nonzero_windows.csv", index=False)
print(pd.DataFrame(rows).round(5).to_string())
