"""Dataset inventory of the 80 runs: runs against the plan, windows by phase, sample completeness, feature coverage, capture times,
recaptures (from the archive folders of the repository), captures outside the plan, stray tunnel values.
Writes out/csv/inv_*.csv.   Reads pkl/pooled_raw.pkl, out/csv/verify_summary.csv and the repository copy (exports only)."""
import os, re, glob, warnings
import numpy as np, pandas as pd
from cfg import *
warnings.filterwarnings("ignore")
O = CSV
ORIG = "/home/claude/thesis3_latest/ESP32-Environment"          # read-only: only the archive folder names and their REPLACED.txt are read
raw = pd.read_pickle(PKL + "/pooled_raw.pkl")
ver = pd.read_csv(O + "/verify_summary.csv")
print(raw.segment.value_counts(dropna=False))
SEG_ORDER = ["pre_baseline", "baseline", "attack", "cooldown", "transition", "no_phase_seen"]

# ---------------------------------------------------------------- 1. windows by kind and phase
ct = pd.crosstab(raw.kind, raw.segment.fillna("none")).reindex(columns=[c for c in SEG_ORDER if c in set(raw.segment.fillna("none"))] + [c for c in set(raw.segment.fillna("none")) if c not in SEG_ORDER])
ct["all windows"] = ct.sum(axis=1)
ct.loc["all runs"] = ct.sum()
ct.to_csv(O + "/inv_windows_by_kind_phase.csv")
print(ct)

# ---------------------------------------------------------------- 2. one row per run
def root_stamp(kind, t, l, s):
    a = {"benign": "baseline"}.get(kind, kind)
    fs = sorted(glob.glob(f"{R}/datasets/exports/{a}/{t}/{l}/{s}/root_*_telem.csv"))
    fs = [f for f in fs if "/trimmed/" not in f]
    m = re.search(r"_r(\d+)_([a-z]+\d{2})_(\d{4})([AP]M)", fs[0]) if fs else None
    return (f"{m.group(2)} {m.group(3)[:2]}:{m.group(3)[2:]} {m.group(4)}" if m else "")
rows = []
for cell, g in raw.groupby("cell"):
    kind, t, l, s = g.kind.iloc[0], g.topology.iloc[0], g.location.iloc[0], g.scenario.iloc[0]
    v = ver[ver.cell == cell].iloc[0]
    seg = g.segment.value_counts()
    k = g[g.phase.notna()]
    rows.append(dict(cell=cell, kind=kind, topology=t, site=l, scenario=s, boards=int(g.node_id.nunique()),
                     windows_all=len(g), pre_baseline=int(seg.get("pre_baseline", 0)), baseline=int(seg.get("baseline", 0)), attack=int(seg.get("attack", 0)),
                     cooldown=int(seg.get("cooldown", 0)), transition_or_no_phase=int(seg.get("transition", 0) + seg.get("no_phase_seen", 0)),
                     mean_samples_per_window=k.n_samples_present.mean(), min_samples_in_kept_window=int(k.n_samples_present.min()),
                     share_kept_below_10_samples=float((k.n_samples_present < 10).mean()),
                     result=v.result, grade=v.grade, scenario_applied=v.scenario_applied, n_notes=int(v.n_notes), verifier_notes=v.notes,
                     root_capture=root_stamp(kind, t, l, s)))
inv = pd.DataFrame(rows)
order = {"blackhole": 0, "wormhole": 1, "benign": 2}
inv["o"] = inv.kind.map(order); inv["ti"] = inv.topology.map({x: i for i, x in enumerate(TOPOS)}); inv["si"] = inv.site.map({x: i for i, x in enumerate(SITES)}); inv["ci"] = inv.scenario.map({x: i for i, x in enumerate(SCEN)})
inv = inv.sort_values(["o", "ti", "si", "ci"]).drop(columns=["o", "ti", "si", "ci"])
inv.to_csv(O + "/inv_runs.csv", index=False)
print(inv[["cell", "boards", "windows_all", "baseline", "attack", "cooldown", "mean_samples_per_window", "min_samples_in_kept_window", "grade", "root_capture"]].to_string())
print("min mean samples/window over runs:", inv.mean_samples_per_window.min(), "| min samples in any kept window:", inv.min_samples_in_kept_window.min())

# ---------------------------------------------------------------- 3. plan against capture
plan = pd.DataFrame(plan_cells(), columns=["attack", "topology", "site", "scenario"])
plan["kind"] = plan.attack.replace({"baseline": "benign"})
have = set(raw.cell)
plan["cell"] = plan.kind + "/" + plan.topology + "/" + plan.site + "/" + plan.scenario
plan["captured"] = plan.cell.isin(have)
plan.to_csv(O + "/inv_plan_vs_captured.csv", index=False)
pv = plan.groupby(["kind", "topology"]).agg(planned=("cell", "size"), captured=("captured", "sum")).reset_index()
pv.to_csv(O + "/inv_runs_by_kind_topology.csv", index=False)
ps = plan.groupby(["kind", "scenario"]).agg(planned=("cell", "size"), captured=("captured", "sum")).reset_index(); ps.to_csv(O + "/inv_runs_by_kind_scenario.csv", index=False)
pl = plan.groupby(["kind", "site"]).agg(planned=("cell", "size"), captured=("captured", "sum")).reset_index(); pl.to_csv(O + "/inv_runs_by_kind_site.csv", index=False)
print(pv); print(ps); print(pl)
print("planned", len(plan), "captured", int(plan.captured.sum()))

# ---------------------------------------------------------------- 4. feature coverage (all windows of the table, as Table 6.4) by group of boards
FE = ["ForwardingRatio", "IngressEgressDelta", "RetryRate", "PDR", "ParentSwitchRate", "HopChangeCount", "HopStabilityDuration", "RSSI_mean", "RSSI_var",
      "RSSI_stability", "RSSI_Hop_Diff", "LatencyHopRatio", "ConsistencyScore", "TunnelIntensity", "TunnelBytes", "TunnelLatency"]
raw["grp"] = np.select([(raw.kind == "blackhole") & (raw.node_role == "blackhole"), (raw.kind == "blackhole") & (raw.node_role == "child"),
                        (raw.kind == "wormhole") & (raw.node_role == "wormhole_a"), (raw.kind == "wormhole") & (raw.node_role == "wormhole_b"),
                        (raw.kind == "wormhole") & (raw.node_role == "child"), (raw.kind == "benign") & (raw.node_role == "child"), raw.node_role == "root"],
                       ["blackhole attacker", "blackhole non-attacker", "wormhole end A", "wormhole end B", "wormhole non-attacker", "benign child", "root"], "other")
cov = raw[raw.grp != "root"].groupby("grp")[FE].agg(lambda s: s.notna().mean() * 100).T.round(1)
cov["non-attacker, all runs"] = raw[raw.grp.isin(["blackhole non-attacker", "wormhole non-attacker", "benign child"])][FE].notna().mean().mul(100).round(1)
cov.to_csv(O + "/inv_feature_coverage_by_group.csv")
print(cov)
print(raw.groupby("grp").size())

# ---------------------------------------------------------------- 5. stray tunnel values
tl = raw[raw.TunnelLatency.notna()].groupby(["kind", "node_role", "phase"], dropna=False).size().rename("windows_with_TunnelLatency").reset_index()
tl.to_csv(O + "/inv_tunnel_latency_values.csv", index=False)
print(tl)
ti = raw[raw.TunnelIntensity.notna() & (raw.TunnelIntensity != 0)].groupby(["kind", "node_role", "phase"], dropna=False).size().rename("nonzero_TunnelIntensity_windows").reset_index()
print(ti)
stray = raw[(raw.grp.isin(["blackhole non-attacker", "wormhole non-attacker", "benign child", "blackhole attacker"])) & raw.TunnelLatency.notna()]
print("stray TunnelLatency values outside the wormhole ends:", len(stray))

# ---------------------------------------------------------------- 6. captures in exports that are outside the final plan
ex = []
for p in glob.glob(f"{R}/datasets/exports/*/*/*/*/root_*_telem.csv"):
    if "/trimmed/" in p: continue
    parts = p.split("/exports/")[1].split("/")
    ex.append(dict(attack=parts[0], topology=parts[1], site=parts[2], scenario=parts[3], file=os.path.basename(p)))
ex = pd.DataFrame(ex)
ex["kind"] = ex.attack.replace({"baseline": "benign"})
ex["cell"] = ex.kind + "/" + ex.topology + "/" + ex.site + "/" + ex.scenario
off = ex[~ex.cell.isin(set(plan.cell))]
off.to_csv(O + "/inv_captures_outside_plan.csv", index=False)
print("captures outside the plan:\n", off[["cell", "file"]].to_string())

# ---------------------------------------------------------------- 7. recaptures from the archive folders
arch = []
for d in sorted(os.listdir(ORIG + "/archive")):
    m = re.match(r"(\d{4}-\d{2}-\d{2})_(blackhole|wormhole|baseline)-(\w+?)-(G402|DLSU_Library|Yuchengco|DLSU|home)-(\w+)-r(\d+)-replaced(-\d+)?$", d)
    if m:
        why = ""
        f = f"{ORIG}/archive/{d}/REPLACED.txt"
        if os.path.exists(f):
            t = open(f).read()
            mv = re.search(r"verdict '([^']*)'", t)
            mt = re.search(r"archived (\S+ \S+)", t)
            why = (mv.group(1) if mv else "")
            when = mt.group(1) if mt else m.group(1)
        else: when = m.group(1)
        arch.append(dict(folder=d, date=m.group(1), archived_at=when, kind={"baseline": "benign"}.get(m.group(2), m.group(2)), topology=m.group(3), site=m.group(4), scenario=m.group(5),
                         repeat=int(m.group(6)), old_verdict_line=why))
arch = pd.DataFrame(arch)
arch.to_csv(O + "/inv_recaptures_replaced.csv", index=False)
print(arch.to_string())
print("replaced captures:", len(arch), "in", arch.groupby(["kind", "topology", "site", "scenario"]).ngroups, "cells")
print(arch.groupby("kind").size())
