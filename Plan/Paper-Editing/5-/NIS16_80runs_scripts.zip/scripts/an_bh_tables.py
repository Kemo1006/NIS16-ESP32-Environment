"""Tables for the blackhole part of Chapter 6 that are not written by the other scripts:
the attack checks of the verifier (Table 6.5), the runs by topology (Table 6.2), the best possible ARI (ceiling) overall and inside each site and topology.
Reads pkl/pooled_raw.pkl, out/csv/verify_*.csv, out/csv/bh_per_cell_summary.csv.  Writes out/csv/bht_*.csv"""
import warnings
import numpy as np, pandas as pd
from sklearn.metrics import adjusted_rand_score
from cfg import *
from clu_lib import FULL
warnings.filterwarnings("ignore")
O = CSV
chk = pd.read_csv(O + "/verify_checks.csv"); chk = chk[chk.kind == "blackhole"]
ver = pd.read_csv(O + "/verify_summary.csv"); ver = ver[ver.kind == "blackhole"]

# ---------------------------------------------------------------- Table 6.5
rows = []
for feat, g in chk.groupby("feature", sort=False):
    passed = int((g.status == "PASS").sum()); fail = int((g.status == "FAIL").sum()); nod = int((g.status == "NO DATA").sum()); exc = int((g.status == "EXCLUDED").sum())
    zf = g[(g.status == "FAIL")].z.replace([np.inf, -np.inf], np.nan)
    zp = g[(g.status == "PASS")].z.replace([np.inf, -np.inf], np.nan)
    rows.append(dict(check=feat, tier=g.tier.iloc[0], runs=len(g), passed=passed, failed=fail, no_data=nod, excluded=exc,
                     z_fail_min=zf.min(), z_fail_max=zf.max(), z_pass_min_finite=zp.abs().min(), undefined_z_runs=int((~np.isfinite(g.z) & g.z.notna()).sum()) + int(g.z.isna().sum() - (g.status.isin(["NO DATA", "EXCLUDED"])).sum()),
                     normal_mean_min=g.normal_mean.min(), normal_mean_max=g.normal_mean.max(), attack_min=g.attack_value.min(), attack_max=g.attack_value.max()))
t5 = pd.DataFrame(rows); t5.to_csv(O + "/bht_attack_checks.csv", index=False)
pd.set_option("display.width", 250); pd.set_option("display.max_columns", 30)
print(t5.round(3).to_string())
fr = chk[chk.feature.str.startswith("ForwardingRatio")]
print("ForwardingRatio attacker: baseline", fr.normal_mean.min(), fr.normal_mean.max(), "| attack", fr.attack_value.min(), fr.attack_value.max())
fin = fr.z.replace([np.inf, -np.inf], np.nan).dropna()
print("finite z for FR:", len(fin), "min |z|", fin.abs().min(), "median |z|", fin.abs().median(), "| undefined/infinite in", int((~np.isfinite(fr.z)).sum()), "runs")
for f in chk.feature.unique():
    g = chk[chk.feature == f]
    print(f, "finite z:", g.z.replace([np.inf, -np.inf], np.nan).dropna().abs().describe()[["count", "min", "50%", "max"]].round(2).to_dict(), "| inf:", int(np.isinf(g.z).sum()))
miss = chk[(chk.status == "FAIL")][["cell", "feature", "z", "normal_mean", "normal_sd", "attack_value"]]
print(miss.round(3).to_string())
excl = chk[chk.status.isin(["EXCLUDED", "NO DATA"])][["cell", "feature", "status", "normal_mean", "normal_sd", "raw"]]
print(excl.to_string())
miss.to_csv(O + "/bht_check_misses.csv", index=False); excl.to_csv(O + "/bht_check_excluded_or_nodata.csv", index=False)

# ---------------------------------------------------------------- Table 6.2: runs by topology (victim and bystander boards from the labelled windows)
raw = pd.read_pickle(PKL + "/pooled_raw.pkl")
bh = raw[(raw.kind == "blackhole") & raw.phase.notna()].copy()
vb = bh[(bh.node_role == "child") & (bh.phase == "attack")].groupby(["topology", "cell", "exposure"]).node_id.nunique().unstack(fill_value=0)
# boards of the whole run that are ever a victim or bystander in an attack window (a board can be both, in a tree run where it changed parent)
ever = bh[(bh.node_role == "child") & (bh.phase == "attack")].groupby(["topology", "cell", "node_id"]).exposure.agg(lambda s: set(s.dropna())).reset_index()
ever["victim_ever"] = ever.exposure.apply(lambda s: "downstream" in s); ever["bystander_ever"] = ever.exposure.apply(lambda s: "upstream" in s)
t2 = ever.groupby("topology").agg(victim_boards=("victim_ever", "sum"), bystander_boards=("bystander_ever", "sum"), boards_both=("exposure", lambda s: int(sum(1 for x in s if len(x) > 1)))).reset_index()
runs = ver.groupby("topology").agg(runs=("cell", "size"), confirmed=("result", lambda s: int((s == "CONFIRMED").sum())),
                                   good=("grade", lambda s: int((s == "GOOD").sum())), minor=("grade", lambda s: int((s == "MINOR GAPS").sum())),
                                   undetermined=("grade", lambda s: int((s == "UNDETERMINED").sum()))).reset_index()
t2 = runs.merge(t2, on="topology")
tot = t2.drop(columns="topology").sum(); tot["topology"] = "all"; t2 = pd.concat([t2, tot.to_frame().T], ignore_index=True)
t2.to_csv(O + "/bht_runs_by_topology.csv", index=False); print(t2)
# boards that are victims in the attack, using the per-board majority exposure
maj = bh[(bh.node_role == "child") & (bh.phase == "attack")].groupby(["topology", "cell", "node_id"]).exposure.agg(lambda s: s.value_counts().index[0]).reset_index()
print(maj.groupby(["topology", "exposure"]).size().unstack(fill_value=0))
maj.groupby(["topology", "exposure"]).size().unstack(fill_value=0).to_csv(O + "/bht_boards_by_majority_exposure.csv")

# ---------------------------------------------------------------- best possible ARI (ceiling): the partition {victim windows in the attack} vs {the rest} against the label
ch = bh[(bh.node_role == "child") & bh.Label.notna()].dropna(subset=FULL).copy()
ch["y"] = (ch.Label > 0).astype(int)
ch["oracle"] = ((ch.exposure == "downstream") & (ch.y == 1)).astype(int)
ceil = [dict(group="all non-attacker nodes", windows=len(ch), best_possible_ARI=adjusted_rand_score(ch.y, ch.oracle),
             attack_windows=int(ch.y.sum()), attack_windows_from_bystanders=int(((ch.y == 1) & (ch.exposure == "upstream")).sum()),
             share_attack_windows_from_bystanders=float(((ch.y == 1) & (ch.exposure == "upstream")).sum() / ch.y.sum()))]
for dim in ("location", "topology"):
    for v, g in ch.groupby(dim):
        ceil.append(dict(group=f"{dim} = {v}", windows=len(g), best_possible_ARI=adjusted_rand_score(g.y, g.oracle), attack_windows=int(g.y.sum()),
                         attack_windows_from_bystanders=int(((g.y == 1) & (g.exposure == "upstream")).sum()),
                         share_attack_windows_from_bystanders=float(((g.y == 1) & (g.exposure == "upstream")).sum() / g.y.sum())))
vic = ch[ch.exposure == "downstream"]
ceil.append(dict(group="victims only", windows=len(vic), best_possible_ARI=adjusted_rand_score(vic.y, vic.oracle), attack_windows=int(vic.y.sum()), attack_windows_from_bystanders=0, share_attack_windows_from_bystanders=0.0))
ceil = pd.DataFrame(ceil); ceil.to_csv(O + "/bht_ari_ceiling.csv", index=False); print(ceil.round(4).to_string())
# the single-label majority rate and the sample shares
print("normal share (all non-attacker nodes):", 1 - ch.y.mean(), "| victims' share of windows:", (ch.exposure == "downstream").mean())
print("windows in the FULL pool:", len(ch), "| PDR-free pool (REDUCED_no_PDR):", int(bh[(bh.node_role == 'child') & bh.Label.notna()].dropna(subset=['RSSI_mean', 'RSSI_var', 'RSSI_Hop_Diff']).shape[0]))
