"""Shared paths, constants and helpers for the final analysis (blackhole + wormhole + benign).
Edit R (the repository copy, ESP32-Environment/ at THESIS3 commit 970fb15) and S (the output folder) to run elsewhere."""
import os, sys
R = os.environ.get("NIS16_REPO", "/tmp/claude-0/-home-claude/9732539a-0151-5fad-ae9e-ea4fd1893dd8/scratchpad/wh/repo")
S = os.environ.get("NIS16_OUT", "/tmp/claude-0/-home-claude/9732539a-0151-5fad-ae9e-ea4fd1893dd8/scratchpad/wh")
PKL = S + "/pkl"; CSV = S + "/out/csv"; FIG = S + "/out/fig"; VER = S + "/verify_out"
for d in (PKL, CSV, FIG): os.makedirs(d, exist_ok=True)
sys.path.insert(0, R + "/analysis")
TOPOS = ["linear", "partial_mesh", "star", "tree"]
SITES = ["G402", "DLSU_Library", "Yuchengco"]
SCEN = ["stationary", "burst", "highload"]
COMMIT = open(R + "/COMMIT.txt").read().strip()[:7]
NOTE = f"All 80 runs · THESIS3 @ {COMMIT} · 24 Oct 2026"
C_BASE, C_ATT, C_COOL, C_GREY = "#2b6cb0", "#c53030", "#718096", "#a0aec0"
C_WH, C_BH, C_BEN = "#6b46c1", "#c53030", "#2f855a"
BENIGN_CELLS = [("linear","G402","highload"),("star","G402","burst"),("tree","G402","stationary"),("partial_mesh","G402","highload"),
                ("linear","DLSU_Library","stationary"),("star","DLSU_Library","stationary"),("linear","Yuchengco","stationary"),("star","Yuchengco","highload")]
def plan_cells():
    out = []
    for a in ("blackhole", "wormhole"):
        for t in TOPOS:
            for l in SITES:
                for s in SCEN: out.append((a, t, l, s))
    for t, l, s in BENIGN_CELLS: out.append(("baseline", t, l, s))
    return out
def ft_path(a, t, l, s): return f"{R}/datasets/analysis/{a}/{t}/{l}/{s}/feature_table.csv"
def mpl():
    import matplotlib; matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"figure.dpi": 130, "savefig.dpi": 160, "font.size": 9, "axes.spines.top": False, "axes.spines.right": False,
                         "axes.titlesize": 10, "axes.titleweight": "bold"})
    return plt


def add_subset_majority(audit, df, label_col="window_label"):
    """The repo's single-feature accuracy of a feature is measured on the windows that HAVE a value, but it is compared with a majority rate
    over all windows. Add the majority rate among the windows that have a value (majority_among_covered) and the lift over that rate."""
    import numpy as np
    lab = df[label_col]; ok = lab.notna()
    out = audit.copy(); maj = []
    for ft in out.feature:
        if ft not in df.columns:
            maj.append(np.nan); continue
        m = ok & df[ft].notna()
        y = (lab[m] > 0)
        maj.append(max(y.mean(), 1 - y.mean()) if m.sum() else np.nan)
    out["majority_among_covered"] = maj
    out["lift_over_covered_majority"] = out.threshold_accuracy - out.majority_among_covered
    return out
