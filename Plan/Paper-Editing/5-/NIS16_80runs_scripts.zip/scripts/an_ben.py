"""Benign runs (8): the stand-alone control. Per-run summary, matched comparison with the baselines of the attack runs of the same cell,
benign against the normal windows of the attack runs, the effect of the traffic scenario, the false-alarm check, and figures.
Normal = baseline + cooldown.  Reads pkl/pooled_raw.pkl, out/csv/verify_*.csv.  Writes out/csv/ben_*.csv, out/fig/ben_fig*.png"""
import warnings
import numpy as np, pandas as pd
from scipy import stats
from cfg import *
warnings.filterwarnings("ignore")
plt = mpl()
O, OF = CSV, FIG
NOTE = f"Benign · 8 runs · THESIS3 @ {COMMIT} · 24 Oct 2026"
raw = pd.read_pickle(PKL + "/pooled_raw.pkl")
use = raw[raw.phase.notna()].copy()
ch = use[use.node_role == "child"].copy()
ben = ch[ch.kind == "benign"]
FEATS = ["PDR", "RetryRate", "RSSI_mean", "RSSI_var", "RSSI_Hop_Diff", "LatencyHopRatio", "ParentSwitchRate", "HopChangeCount", "HopStabilityDuration", "RSSI_stability"]


def cohen_d(a, b):
    a, b = a.dropna(), b.dropna()
    if len(a) < 2 or len(b) < 2: return np.nan
    s = np.sqrt((a.var(ddof=1) + b.var(ddof=1)) / 2)
    return (b.mean() - a.mean()) / s if s > 0 else np.nan


# ---------------------------------------------------------------- 1. per-run summary
ver = pd.read_csv(O + "/verify_summary.csv"); ver = ver[ver.kind == "benign"]
rows = []
for cell, g in use[use.kind == "benign"].groupby("cell"):
    c = g[g.node_role == "child"]
    b, k = c[c.phase == "baseline"], c[c.phase == "cooldown"]
    v = ver[ver.cell == cell].iloc[0]
    rows.append(dict(cell=cell, topology=g.topology.iloc[0], site=g.location.iloc[0], scenario=g.scenario.iloc[0],
                     boards=int(g.node_id.nunique()), child_boards=int(c.node_id.nunique()),
                     baseline_windows=int((g.phase == "baseline").sum()), cooldown_windows=int((g.phase == "cooldown").sum()),
                     PDR_baseline=b.PDR.mean(), PDR_cooldown=k.PDR.mean(), PDR_min_window=c.PDR.min(),
                     windows_PDR_below_1=int((c.PDR < 1).sum()), share_PDR_below_1=float((c.PDR < 1).mean()),
                     RetryRate_baseline=b.RetryRate.mean(), RetryRate_cooldown=k.RetryRate.mean(),
                     RSSI_mean_baseline=b.RSSI_mean.mean(), RSSI_var_baseline=b.RSSI_var.mean(),
                     LatencyHopRatio_median_baseline=b.LatencyHopRatio.median(), LatencyHopRatio_median_cooldown=k.LatencyHopRatio.median(),
                     parent_changes=int((c.ParentSwitchRate > 0).sum()), hop_changes=int((c.HopChangeCount > 0).sum()),
                     max_hop=int(c.hop.max()), verifier=v.result, grade=v.grade, notes=v.notes))
per = pd.DataFrame(rows)
per.to_csv(O + "/ben_per_run.csv", index=False)
pd.set_option("display.width", 260); pd.set_option("display.max_columns", 40)
print(per.drop(columns=["notes"]).round(4).to_string())

# ---------------------------------------------------------------- 2. matched comparison: baseline of the benign run against the baseline of the attack runs of the same cell
m_rows = []
for _, r in per.iterrows():
    bb = ben[(ben.cell == r.cell) & (ben.phase == "baseline")]
    for kind in ("blackhole", "wormhole"):
        cell = f"{kind}/{r.topology}/{r.site}/{r.scenario}"
        ab = ch[(ch.cell == cell) & (ch.phase == "baseline")]
        for f in ("PDR", "RSSI_mean", "RSSI_var", "RSSI_Hop_Diff", "LatencyHopRatio"):
            m_rows.append(dict(benign_cell=r.cell, attack_kind=kind, feature=f, benign_mean=bb[f].mean(), attack_run_baseline_mean=ab[f].mean(),
                               difference=bb[f].mean() - ab[f].mean(), d=cohen_d(ab[f], bb[f]), benign_n=int(bb[f].notna().sum()), attack_n=int(ab[f].notna().sum())))
mt = pd.DataFrame(m_rows); mt.to_csv(O + "/ben_matched_baseline_comparison.csv", index=False)
ms = mt.groupby(["attack_kind", "feature"]).agg(runs=("d", "size"), mean_difference=("difference", "mean"), mean_abs_difference=("difference", lambda s: s.abs().mean()),
                                                  median_d=("d", "median"), max_abs_d=("d", lambda s: s.abs().max())).reset_index()
ms.to_csv(O + "/ben_matched_summary.csv", index=False)
print(ms.round(3).to_string())

# ---------------------------------------------------------------- 3. benign against the normal windows of the attack runs (all runs pooled; per feature)
norm = ch[ch.phase.isin(["baseline", "cooldown"])]
rows = []
for f in FEATS:
    b = norm[norm.kind == "benign"][f]
    for kind in ("blackhole", "wormhole"):
        a = norm[norm.kind == kind][f]
        rows.append(dict(feature=f, attack_kind=kind, benign_mean=b.mean(), benign_sd=b.std(), benign_n=int(b.notna().sum()),
                         attack_run_normal_mean=a.mean(), attack_run_normal_sd=a.std(), attack_run_normal_n=int(a.notna().sum()), d=cohen_d(a, b)))
cmp_ = pd.DataFrame(rows); cmp_.to_csv(O + "/ben_vs_normal_of_attack_runs.csv", index=False)
print(cmp_.round(4).to_string())

# ---------------------------------------------------------------- 4. scenario effect on normal windows (children): benign and the attack runs
rows = []
for sc in SCEN:
    for label, sel in (("benign runs", norm.kind == "benign"), ("attack runs (baseline + cooldown)", norm.kind != "benign")):
        g = norm[sel & (norm.scenario == sc)]
        rows.append(dict(scenario=sc, group=label, runs=int(g.cell.nunique()), windows=len(g), PDR_mean=g.PDR.mean(), PDR_share_below_1=float((g.PDR < 1).mean()),
                         RetryRate_mean=g.RetryRate.mean(), LatencyHopRatio_median=g.LatencyHopRatio.median(), LatencyHopRatio_p90=g.LatencyHopRatio.quantile(.9),
                         RSSI_mean=g.RSSI_mean.mean(), RSSI_var=g.RSSI_var.mean(), probes_per_s=(g.probes_count_delta + g.retry_count_delta).mean()))
sc_ = pd.DataFrame(rows); sc_.to_csv(O + "/ben_scenario_effect.csv", index=False)
print(sc_.round(4).to_string())

# ---------------------------------------------------------------- 5. false-alarm check: the verifier's own checks on the benign runs (what an attack signature would need to move)
chk = pd.read_csv(O + "/verify_checks.csv"); chk = chk[chk.kind == "benign"]
chk.to_csv(O + "/ben_false_alarm_checks.csv", index=False)
print(chk[["cell", "feature", "status", "normal_mean", "attack_value", "z"]].round(3).to_string())
# cooldown versus baseline, by run: how far the cooldown mean of each feature lies from the baseline mean, in baseline standard deviations
rows = []
for cell, g in ben.groupby("cell"):
    for f in ("PDR", "RSSI_mean", "RSSI_var", "LatencyHopRatio"):
        b, k = g[g.phase == "baseline"][f].dropna(), g[g.phase == "cooldown"][f].dropna()
        # pooled in blocks of 5 windows, as the verifier does (Table 4.10)
        def blocks(s): return s.groupby(np.arange(len(s)) // 5).mean()
        bb, kk = blocks(b), blocks(k)
        z = (kk.mean() - bb.mean()) / bb.std(ddof=1) if bb.std(ddof=1) > 0 else np.nan
        rows.append(dict(cell=cell, feature=f, baseline_mean=b.mean(), cooldown_mean=k.mean(), z_cooldown_vs_baseline=z, windows_baseline=len(b), windows_cooldown=len(k)))
fa = pd.DataFrame(rows); fa.to_csv(O + "/ben_cooldown_vs_baseline.csv", index=False)
print(fa.round(3).to_string())

# ---------------------------------------------------------------- 6. benign share of windows with PDR < 1 and distribution of per-board PDR (what 'normal' looks like in the first place)
pb = ben.groupby(["cell", "node_id"]).PDR.agg(mean="mean", min="min", below1=lambda s: int((s < 1).sum())).reset_index()
pb.to_csv(O + "/ben_per_board_pdr.csv", index=False)
print("boards with any window below PDR 1:", int((pb.below1 > 0).sum()), "of", len(pb))

# ================================================================== figures
C_B = "#2f855a"
TOPO_COL = {"linear": "#2b6cb0", "partial_mesh": "#dd6b20", "star": "#805ad5", "tree": "#2f855a"}
# fig 1: delivery of the child boards in the 8 benign runs (zoomed: PDR is 1.0 almost everywhere)
fig, axes = plt.subplots(1, 2, figsize=(12.4, 4.2), gridspec_kw=dict(width_ratios=[1.35, 1]))
ax = axes[0]
for _, r in per.iterrows():
    g = ben[ben.cell == r.cell]
    mv = g.pivot_table(index="t_rel", columns="node_id", values="PDR").rolling(5, min_periods=1, center=True).mean().mean(axis=1)
    ax.plot(mv.index, mv, lw=1.3, color=TOPO_COL[r.topology], alpha=.85,
            ls={"stationary": "-", "burst": "--", "highload": ":"}[r.scenario],
            label=f"{r.topology.replace('_', ' ')} · {r.site.replace('_', ' ')} · {r.scenario}")
ax.axvspan(0, 120, color="#edf2f7", zorder=0)
ax.set_ylim(0.95, 1.004); ax.set_xlabel("time from the end of the baseline (s)"); ax.set_ylabel("mean PDR of the child boards")
ax.set_title("Mean PDR of each run (shaded: cooldown)", fontsize=9.5)
ax.legend(frameon=False, fontsize=6.5, ncol=2, loc="lower left")
ax = axes[1]
pbd = pb.copy(); pbd["run"] = pbd.cell.str.replace("benign/", "", regex=False).str.replace("_", " ").str.replace("/", " · ")
runs = list(per.cell)
for j, c in enumerate(runs):
    d = pbd[pbd.cell == c]
    ax.scatter(np.full(len(d), j) + np.random.RandomState(j).uniform(-.18, .18, len(d)), d["min"], s=16, color=TOPO_COL[per[per.cell == c].topology.iloc[0]], alpha=.85, lw=0)
ax.set_xticks(range(len(runs))); ax.set_xticklabels([f"{r.topology.replace('_', ' ')}\n{r.site.replace('_', ' ')}\n{r.scenario}" for _, r in per.iterrows()], fontsize=6)
ax.set_ylabel("lowest PDR of the board in any window"); ax.set_ylim(0.7, 1.02)
ax.set_title(f"Lowest window PDR of each board ({int((pb.below1 > 0).sum())} of {len(pb)} boards ever below 1)", fontsize=9.5)
fig.suptitle("Delivery in the 8 benign runs", fontweight="bold")
fig.text(0.01, -0.03, NOTE + " · line style: solid = stationary, dashed = burst, dotted = highload", fontsize=7, color=C_GREY)
fig.tight_layout(); fig.savefig(OF + "/ben_fig1_pdr_timeseries.png", bbox_inches="tight"); plt.close(fig)

# fig 2: benign against the normal windows of the attack runs
fs = ["RSSI_mean", "RSSI_var", "RSSI_Hop_Diff", "LatencyHopRatio", "PDR_below1"]
fig, axes = plt.subplots(1, 5, figsize=(13.2, 3.5))
grp = [("benign", norm[norm.kind == "benign"], C_B), ("blackhole runs", norm[norm.kind == "blackhole"], C_BH), ("wormhole runs", norm[norm.kind == "wormhole"], C_WH)]
for ax, f in zip(axes, fs):
    if f == "PDR_below1":
        v = [float((g.PDR.dropna() < 1).mean() * 100) for _, g, _ in grp]
        ax.bar(range(3), v, color=[c for _, _, c in grp], alpha=.6, width=.55)
        for i, vv in enumerate(v): ax.text(i, vv, f"{vv:.2f} %", ha="center", va="bottom", fontsize=7)
        ax.set_xticks(range(3)); ax.set_xticklabels(["benign", "blackhole\nruns", "wormhole\nruns"]); ax.margins(y=.2)
        ax.set_title("windows with PDR below 1 (%)", fontsize=8.5)
    else:
        data = [g[f].dropna().values for _, g, _ in grp]
        if f == "LatencyHopRatio": data = [np.log10(1 + np.clip(d, 0, None)) for d in data]
        bp = ax.boxplot(data, tick_labels=["benign", "blackhole\nruns", "wormhole\nruns"], showfliers=False, patch_artist=True, widths=.55)
        for p, (_, _, c) in zip(bp["boxes"], grp): p.set_facecolor(c); p.set_alpha(.45)
        for m in bp["medians"]: m.set_color("black")
        ax.set_title(f + (" (log10 of 1 + value)" if f == "LatencyHopRatio" else ""), fontsize=8.5)
    ax.tick_params(axis="x", labelsize=7.5)
fig.suptitle("Normal windows (baseline and cooldown) of the child boards: benign runs against the attack runs", fontweight="bold", y=1.04)
fig.text(0.01, -0.07, NOTE, fontsize=7, color=C_GREY)
fig.tight_layout(); fig.savefig(OF + "/ben_fig2_normal_windows_compared.png", bbox_inches="tight"); plt.close(fig)

# fig 3: scenario effect on normal windows
fig, axes = plt.subplots(1, 3, figsize=(11.6, 3.7))
for ax, (col, ttl, fmt) in zip(axes, [("PDR_mean", "mean PDR (vertical axis starts at 0.90)", "{:.4f}"), ("LatencyHopRatio_median", "median LatencyHopRatio (ms per hop)", "{:.2f}"), ("probes_per_s", "probes sent per board per second", "{:.2f}")]):
    w = .36
    for i, (label, c) in enumerate((("benign runs", C_B), ("attack runs (baseline + cooldown)", C_GREY))):
        v = [sc_[(sc_.scenario == s) & (sc_.group == label)][col].iloc[0] for s in SCEN]
        n = [int(sc_[(sc_.scenario == s) & (sc_.group == label)].runs.iloc[0]) for s in SCEN]
        ax.bar(np.arange(3) + (i - .5) * w, v, w, color=c, label=label.replace(" (baseline + cooldown)", ""))
        for xx, vv, nn in zip(np.arange(3) + (i - .5) * w, v, n):
            ax.text(xx, vv, fmt.format(vv) + f"\n(n = {nn})", ha="center", va="bottom", fontsize=6)
    ax.set_xticks(range(3)); ax.set_xticklabels(SCEN); ax.set_title(ttl, fontsize=9)
    ax.margins(y=.28)
    if col == "PDR_mean": ax.set_ylim(0.9, 1.012)
axes[1].legend(frameon=False, fontsize=7.5, loc="upper right")
fig.suptitle("Effect of the traffic scenario on normal windows of the child boards (n = number of runs)", fontweight="bold", y=1.04)
fig.text(0.01, -0.04, NOTE, fontsize=7, color=C_GREY)
fig.tight_layout(); fig.savefig(OF + "/ben_fig3_scenario_effect.png", bbox_inches="tight"); plt.close(fig)

# fig 4: run-level placement effect: baseline RSSI_mean of each benign run against the baseline of the matched attack run
fig, axes = plt.subplots(1, 2, figsize=(9.6, 4.2), sharex=True, sharey=True)
for ax, kind, c in zip(axes, ("blackhole", "wormhole"), (C_BH, C_WH)):
    d = mt[(mt.attack_kind == kind) & (mt.feature == "RSSI_mean")]
    for _, r in d.iterrows():
        t = r.benign_cell.split("/")[1]
        ax.scatter(r.attack_run_baseline_mean, r.benign_mean, s=38, color=TOPO_COL[t], edgecolor="white", lw=.6, zorder=3)
    lo, hi = float(min(mt[mt.feature == "RSSI_mean"].benign_mean.min(), mt[mt.feature == "RSSI_mean"].attack_run_baseline_mean.min())) - 2, float(max(mt[mt.feature == "RSSI_mean"].benign_mean.max(), mt[mt.feature == "RSSI_mean"].attack_run_baseline_mean.max())) + 2
    ax.plot([lo, hi], [lo, hi], color="#333", lw=1, ls="--"); ax.fill_between([lo, hi], [lo - 3, hi - 3], [lo + 3, hi + 3], color="#e2e8f0", alpha=.6, lw=0, zorder=0)
    ax.set_xlim(lo, hi); ax.set_ylim(lo, hi); ax.set_aspect("equal")
    ax.set_title(f"against the {kind} run of the same cell (mean |difference| {d.difference.abs().mean():.1f} dB)", fontsize=8.5)
    ax.set_xlabel(f"baseline RSSI_mean of the {kind} run (dBm)")
axes[0].set_ylabel("baseline RSSI_mean of the benign run (dBm)")
from matplotlib.lines import Line2D
fig.legend(handles=[Line2D([], [], marker="o", ls="", color=v, label=k.replace("_", " ")) for k, v in TOPO_COL.items()], loc="lower center", ncol=4, frameon=False, fontsize=8, bbox_to_anchor=(.5, -.06))
fig.suptitle("Same cell, different capture: the baseline signal strength moves from run to run (dashed: equal, band: ±3 dB)", fontweight="bold", fontsize=10)
fig.text(0.01, -0.1, NOTE, fontsize=7, color=C_GREY)
fig.tight_layout(); fig.savefig(OF + "/ben_fig4_run_level_rssi.png", bbox_inches="tight"); plt.close(fig)
print("done")
