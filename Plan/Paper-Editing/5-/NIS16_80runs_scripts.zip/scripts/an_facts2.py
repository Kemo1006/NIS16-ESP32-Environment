"""More facts quoted in Section 6.3: Pearson correlations of Figure 5 (same sample as the figure) and the retry-rate effect size of the blackhole runs.
Reads pkl/bh_use.pkl.  Writes out/csv/bh_pearson_{all,baseline,attack}.csv and bh_retry_effect.csv"""
import numpy as np, pandas as pd
from cfg import *
import leakage
use = pd.read_pickle(PKL + "/bh_use.pkl")
ch = use[use.node_role == "child"].copy()
allowed, excluded = leakage.split_columns(use)
cf = [f for f in allowed if f in ch.columns and ch[f].notna().mean() > .3]
print("features in the correlation figure:", cf)
def mats(d):
    x = d[cf].dropna(thresh=int(len(cf) * .7))
    if len(x) > 40000: x = x.sample(40000, random_state=1)
    return x.corr(method="pearson"), x.corr(method="spearman"), len(x)
for name, d in (("all", ch), ("baseline", ch[ch.segment == "baseline"]), ("attack", ch[ch.segment == "attack"])):
    p, s, n = mats(d)
    p.to_csv(CSV + f"/bh_pearson_{name}.csv")
    old = pd.read_csv(CSV + f"/bh_spearman_{name}.csv", index_col=0)
    diff = np.nanmax(np.abs(old.values - s.values))
    print(name, "n =", n, "| spearman reproduces the saved file (max abs diff):", round(float(diff), 6))
# retry-rate effect size, blackhole non-attacker boards
rows = []
for expo, tag in (("downstream", "victims"), ("upstream", "bystanders")):
    b = ch[(ch.exposure == expo) & (ch.segment == "baseline")].RetryRate.dropna()
    a = ch[(ch.exposure == expo) & (ch.segment == "attack")].RetryRate.dropna()
    sp = np.sqrt(((len(b) - 1) * b.var() + (len(a) - 1) * a.var()) / (len(a) + len(b) - 2))
    rows.append(dict(group=tag, n_baseline=len(b), n_attack=len(a), baseline_mean=b.mean(), attack_mean=a.mean(), baseline_sd=b.std(), attack_sd=a.std(), cohens_d=(a.mean() - b.mean()) / sp if sp > 0 else np.nan))
pd.DataFrame(rows).to_csv(CSV + "/bh_retry_effect.csv", index=False)
print(pd.DataFrame(rows).round(5).to_string())

# ---- stationary attack runs: the mean PDR of the normal windows with and without the one run whose baseline is unstable
raw = pd.read_pickle(PKL + "/pooled_raw.pkl")
k = raw[raw.phase.notna() & (raw.node_role == "child") & raw.kind.isin(["blackhole", "wormhole"]) & (raw.phase.isin(["baseline", "cooldown"]))]
rows = []
for sc in ("stationary", "burst", "highload"):
    g = k[k.scenario == sc]
    odd = (g.kind == "blackhole") & (g.topology == "partial_mesh") & (g.location == "Yuchengco") & (g.scenario == "stationary")
    rows.append(dict(scenario=sc, windows=int(g.PDR.notna().sum()), PDR_mean=g.PDR.mean(), PDR_share_below_1=float((g.PDR.dropna() < 1).mean()),
                     PDR_mean_without_odd_run=g[~odd].PDR.mean(), PDR_share_below_1_without_odd_run=float((g[~odd].PDR.dropna() < 1).mean()), odd_run_windows=int(g[odd].PDR.notna().sum()), odd_run_PDR=g[odd].PDR.mean() if odd.any() else np.nan))
pd.DataFrame(rows).to_csv(CSV + "/facts_scenario_pdr.csv", index=False)
print(pd.DataFrame(rows).round(5).to_string())

# ---- lowest value of the 5 s smoothed mean PDR plotted in Figure ben_fig1 (benign runs)
ben = raw[raw.phase.notna() & (raw.node_role == "child") & (raw.kind == "benign")]
rows = []
for cell, g in ben.groupby("cell"):
    mv = g.pivot_table(index="t_rel", columns="node_id", values="PDR").rolling(5, min_periods=1, center=True).mean().mean(axis=1)
    rows.append(dict(cell=cell, smoothed_mean_PDR_min=float(mv.min())))
pd.DataFrame(rows).to_csv(CSV + "/facts_ben_smoothed_pdr_min.csv", index=False)
print(pd.DataFrame(rows).round(4).to_string())
