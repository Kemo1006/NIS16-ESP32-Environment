"""Step 1. Pool the 80 feature tables (36 blackhole, 36 wormhole, 8 benign) into one frame.
Adds: run (attack/topology/site/scenario), cell, kind, phase, per-board time axis t_rel (seconds from that board's first attack
window; for a benign run, from the first cooldown window, i.e. the moment an attack would have started)."""
import pandas as pd, numpy as np
from cfg import *
frames = []
for a, t, l, s in plan_cells():
    d = pd.read_csv(ft_path(a, t, l, s))
    d["kind"] = {"baseline": "benign"}.get(a, a)
    d["topology"], d["location"], d["scenario"] = t, l, s
    d["cell"] = f"{d.kind.iloc[0]}/{t}/{l}/{s}"
    d["rowid_in_table"] = np.arange(len(d))
    frames.append(d)
df = pd.concat(frames, ignore_index=True)
df["phase"] = df.segment.where(df.segment.isin(["baseline", "attack", "cooldown"]))
# per-board clock: each board counts window_start from its own boot, so phases are aligned per board
a0 = df[df.phase == "attack"].groupby(["cell", "node_id"]).window_start.min().rename("a0")
c0 = df[df.phase == "cooldown"].groupby(["cell", "node_id"]).window_start.min().rename("c0")
df = df.join(a0, on=["cell", "node_id"]).join(c0, on=["cell", "node_id"])
df["a0"] = df.a0.fillna(df.c0)                   # benign: no attack phase, so the first cooldown window marks the same point
df["t_rel"] = df.window_start - df.a0
df.drop(columns=["c0"], inplace=True)
df.to_pickle(PKL + "/pooled_raw.pkl")
print(df.shape, df.cell.nunique(), "cells")
print(df.groupby("kind").agg(rows=("cell", "size"), cells=("cell", "nunique"), boards=("node_id", "nunique")))
print(pd.crosstab(df.kind, df.segment))
print(pd.crosstab(df.kind, df.node_role))
print(pd.crosstab([df.kind, df.node_role], df.exposure.fillna("NA")))
print(df.groupby("cell").node_id.nunique().value_counts().sort_index())
