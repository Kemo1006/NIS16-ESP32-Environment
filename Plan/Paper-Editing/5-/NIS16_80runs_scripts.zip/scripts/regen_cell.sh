#!/bin/bash
# Re-create feature_table.csv for one capture, the same three steps analyze.ps1 runs: trim_run --apply -> preprocess -> features.
# usage: regen_cell.sh <repo_copy> <attack> <topology> <location> <scenario> [outdir]
R=$1; A=$2; T=$3; L=$4; S=$5
SRC=$R/datasets/exports/$A/$T/$L/$S
OUT=${6:-$R/datasets/analysis/$A/$T/$L/$S}
mkdir -p "$OUT"
export PYTHONUTF8=1
python3 $R/tools/trim_run.py "$SRC" --apply > "$OUT/regen_trim.log" 2>&1 || echo "trim failed $?" >> "$OUT/regen_trim.log"
SD="$SRC"; [ -d "$SRC/trimmed" ] && SD="$SRC/trimmed"
python3 $R/analysis/preprocess.py "$SD" -o "$OUT/windowed_dataset.csv" > "$OUT/regen_preprocess.log" 2>&1 || { echo "PREPROCESS FAILED $A/$T/$L/$S"; exit 1; }
python3 $R/analysis/features.py "$SD" -o "$OUT/feature_table.csv" > "$OUT/regen_features.log" 2>&1 || { echo "FEATURES FAILED $A/$T/$L/$S"; exit 1; }
echo "ok $A/$T/$L/$S $(wc -l < $OUT/feature_table.csv) rows"
