"""Shared clustering helpers for the wormhole, pooled three-label and benign analyses.
Same procedure as an_bh_cluster.py (Chapter 4, Section 4.2.5): five algorithms, standardised features (Eq. 4.18), k = 2..8,
seeds 42 / 7 / 123, samples of 6,000 windows, DBSCAN with min_samples in {D+1, 1.5D, 2D} and eps at the knee of the k-distance graph.
Internal metrics: silhouette, Davies-Bouldin. External (post-hoc, never used to form a cluster): purity, adjusted Rand index."""
import math, time, warnings
import numpy as np, pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans, DBSCAN, AgglomerativeClustering, SpectralClustering
from sklearn.mixture import GaussianMixture
from sklearn.metrics import silhouette_score, davies_bouldin_score, adjusted_rand_score
from sklearn.neighbors import NearestNeighbors
warnings.filterwarnings("ignore")

SEEDS = [42, 7, 123]
KS = list(range(2, 9))
N_SAMPLE = 6000
# the three feature sets of Table 6.9 (derived on the blackhole windows in an_bh_cluster.py; re-derived and checked here)
FULL = ["PDR", "ParentSwitchRate", "HopChangeCount", "HopStabilityDuration", "RSSI_mean", "RSSI_var", "RSSI_stability", "RSSI_Hop_Diff"]
REDUCED = ["PDR", "RSSI_mean", "RSSI_var", "RSSI_Hop_Diff"]
NOPDR = ["RSSI_mean", "RSSI_var", "RSSI_Hop_Diff"]
SETS = {"FULL": FULL, "REDUCED": REDUCED, "REDUCED_no_PDR": NOPDR}


def purity(y, c):
    df = pd.DataFrame({"y": y, "c": c})
    return df.groupby("c").y.agg(lambda s: s.value_counts().iloc[0]).sum() / len(df)


def knee(sorted_d):
    x = np.arange(len(sorted_d), dtype=float)
    y = sorted_d.astype(float)
    xn, yn = (x - x.min()) / (x.max() - x.min()), (y - y.min()) / (y.max() - y.min() + 1e-12)
    return float(y[int(np.argmax(xn - yn))])


def internal(X, lab):
    m = lab != -1
    if len(set(lab[m])) < 2 or m.sum() < 10:
        return np.nan, np.nan
    return silhouette_score(X[m], lab[m]), davies_bouldin_score(X[m], lab[m])


def fit(algo, X, k, seed):
    if algo == "KMeans": return KMeans(k, n_init=10, random_state=seed).fit_predict(X)
    if algo == "Ward": return AgglomerativeClustering(k, linkage="ward").fit_predict(X)
    if algo == "GMM": return GaussianMixture(k, covariance_type="full", random_state=seed, reg_covar=1e-4).fit(X).predict(X)
    if algo == "Spectral": return SpectralClustering(k, affinity="nearest_neighbors", n_neighbors=15, random_state=seed).fit_predict(X)
    raise ValueError(algo)


def dbscan_search(X, D, seed):
    best, log = None, []
    for ms in sorted({D + 1, int(math.ceil(1.5 * D)), 2 * D}):
        nn = NearestNeighbors(n_neighbors=ms).fit(X)
        kd = np.sort(nn.kneighbors(X)[0][:, -1])
        eps = max(knee(kd), 1e-3)
        lab = DBSCAN(eps=eps, min_samples=ms).fit_predict(X)
        ncl = len(set(lab)) - (1 if -1 in lab else 0)
        noise = float((lab == -1).mean())
        sil, db = internal(X, lab)
        log.append(dict(min_samples=ms, eps=eps, clusters=ncl, noise=noise, silhouette=sil, DB=db))
        key = (-(sil if np.isfinite(sil) else -9)) if noise < .5 else 9
        if best is None or key < best[0]:
            best = (key, ms, eps, lab, kd)
    return best, log


def external(y, lab, oracle=None):
    """purity, ARI and the majority rate against the label y; if oracle (a 0/1 array) is given, also the ARI of that
    partition against y (the best a method reading only one window's features could do) and its purity."""
    out = dict(purity=purity(y, lab), ARI=adjusted_rand_score(y, lab), majority=pd.Series(y).value_counts(normalize=True).iloc[0])
    yb = (np.asarray(y) > 0).astype(int)
    out["ARI_binary"] = adjusted_rand_score(yb, lab)
    if oracle is not None:
        out["ARI_oracle"] = adjusted_rand_score(y, oracle)
    return out


def sweep(base, sets, label_col, pop, oracle_col=None, seeds=SEEDS, ks=KS, n_sample=N_SAMPLE,
          algos=("KMeans", "Ward", "GMM", "Spectral"), keep_km=(2, 3, 4), log=print):
    """Full sweep on one population. Returns (results DataFrame, DBSCAN search log DataFrame, assign_store)."""
    rows, dbrows, store = [], [], {}
    t0 = time.time()
    for seed in seeds:
        samp = base.sample(min(n_sample, len(base)), random_state=seed)
        y = samp[label_col].values
        orc = samp[oracle_col].values.astype(int) if oracle_col else None
        for sname, feats in sets.items():
            X = StandardScaler().fit_transform(samp[feats].values)
            D = X.shape[1]
            (key, ms, eps, lab, kd), lg = dbscan_search(X, D, seed)
            for l in lg: dbrows.append(dict(population=pop, seed=seed, feature_set=sname, **l))
            sil, db = internal(X, lab)
            ncl = len(set(lab)) - (1 if -1 in lab else 0)
            rows.append(dict(population=pop, feature_set=sname, algorithm="DBSCAN", k=ncl, seed=seed, silhouette=sil, DB=db,
                             noise=float((lab == -1).mean()), eps=eps, min_samples=ms, **external(y, lab, orc)))
            if seed == 42:
                store[(pop, sname, "DBSCAN")] = (samp.index.values, lab, kd, eps)
            for algo in algos:
                for k in ks:
                    lab = fit(algo, X, k, seed)
                    sil, db = internal(X, lab)
                    rows.append(dict(population=pop, feature_set=sname, algorithm=algo, k=k, seed=seed, silhouette=sil, DB=db,
                                     noise=0.0, eps=np.nan, min_samples=np.nan, **external(y, lab, orc)))
                    if seed == 42 and algo == "KMeans" and k in keep_km:
                        store[(pop, sname, f"KMeans{k}")] = (samp.index.values, lab, None, None)
        log(f"  {pop} seed {seed} done ({time.time() - t0:.0f}s)")
    return pd.DataFrame(rows), pd.DataFrame(dbrows), store


METRICS = ["silhouette", "DB", "purity", "ARI", "ARI_binary", "majority", "noise"]


def summarise(res):
    """mean over seeds per (population, feature set, algorithm, k); DBSCAN averaged per (population, feature set)."""
    has_or = "ARI_oracle" in res
    cols = METRICS + (["ARI_oracle"] if has_or else [])
    mk = res[res.algorithm != "DBSCAN"]
    keys = ["population", "feature_set", "algorithm", "k"]
    agg = mk.groupby(keys)[cols].mean().reset_index()
    sd = mk.groupby(keys)[["silhouette", "ARI"]].std().reset_index().rename(columns={"silhouette": "sil_sd", "ARI": "ARI_sd"})
    agg = agg.merge(sd, on=keys)
    db = res[res.algorithm == "DBSCAN"]
    dbagg = db.groupby(["population", "feature_set", "algorithm"]).agg(
        k=("k", "mean"), k_per_seed=("k", lambda s: "/".join(str(int(v)) for v in s)),
        **{m: (m, "mean") for m in cols}).reset_index()
    dbagg["k_per_seed"] = dbagg["k_per_seed"].astype(str)
    best_rows = []
    for _, g in agg.groupby(["population", "feature_set", "algorithm"]):
        g = g.dropna(subset=["silhouette"])
        if len(g): best_rows.append(g.loc[g.silhouette.idxmax()])
    best = pd.DataFrame(best_rows); best["selection"] = "best silhouette"
    kfix = agg[agg.k == 2].copy(); kfix["selection"] = "k = 2"
    k3 = agg[agg.k == 3].copy(); k3["selection"] = "k = 3"
    dbs = dbagg.copy(); dbs["selection"] = "DBSCAN (own k)"
    summary = pd.concat([best, kfix, k3, dbs]).sort_values(["population", "feature_set", "algorithm", "selection"])
    return agg, dbagg, summary
